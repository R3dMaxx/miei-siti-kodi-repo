"""Small XMLTV reader for the Italian evening guide.

The guide is supplied by the user. No programme data is bundled with the add-on.
"""

import gzip
import io
import re
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


try:
    ROME = ZoneInfo("Europe/Rome")
except ZoneInfoNotFoundError:
    # Some Android Python builds have no IANA timezone database. Kodi devices
    # configured for Italy still expose their current local UTC offset.
    ROME = datetime.now().astimezone().tzinfo
MAX_DOWNLOAD = 12 * 1024 * 1024
MAX_XML = 48 * 1024 * 1024
MOVIE_WORDS = ("film", "movie", "cinema", "cinematograf")
SERIES_WORDS = ("serie", "series", "fiction", "telefilm", "serial", "miniserie")


def download_xmltv(url):
    request = urllib.request.Request(url, headers={"User-Agent": "MediaHub Italia/0.1.7"})
    with urllib.request.urlopen(request, timeout=20) as response:
        data = response.read(MAX_DOWNLOAD + 1)
    if len(data) > MAX_DOWNLOAD:
        raise ValueError("La guida supera il limite di 12 MB")
    if data[:2] == b"\x1f\x8b":
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
            data = stream.read(MAX_XML + 1)
    if len(data) > MAX_XML:
        raise ValueError("La guida XML supera il limite di 48 MB")
    return data


def xmltv_time(value):
    value = (value or "").strip()
    match = re.match(r"^(\d{12}(?:\d{2})?)(?:\s*([+-]\d{4}|Z))?", value)
    if not match:
        return None
    digits, offset = match.groups()
    fmt = "%Y%m%d%H%M%S" if len(digits) == 14 else "%Y%m%d%H%M"
    parsed = datetime.strptime(digits, fmt)
    if offset == "Z":
        parsed = parsed.replace(tzinfo=timezone.utc)
    elif offset:
        sign = 1 if offset[0] == "+" else -1
        delta = timedelta(hours=int(offset[1:3]), minutes=int(offset[3:5]))
        parsed = parsed.replace(tzinfo=timezone(sign * delta))
    else:
        parsed = parsed.replace(tzinfo=ROME)
    return parsed.astimezone(ROME)


def _preferred_text(parent, tag):
    values = parent.findall(tag)
    for element in values:
        if element.get("lang", "").lower().startswith("it") and element.text:
            return element.text.strip()
    return next((el.text.strip() for el in values if el.text and el.text.strip()), "")


def kind_for(categories):
    joined = " ".join(categories).casefold()
    if any(word in joined for word in MOVIE_WORDS):
        return "Film"
    if any(word in joined for word in SERIES_WORDS):
        return "Serie TV"
    return ""


def evening_bounds(now=None):
    now = (now or datetime.now(ROME)).astimezone(ROME)
    day = now.date() if now.hour >= 2 else (now - timedelta(days=1)).date()
    start = datetime.combine(day, time(18), ROME)
    end = datetime.combine(day + timedelta(days=1), time(2), ROME)
    return start, end


def parse_evening(data, now=None):
    start_window, end_window = evening_bounds(now)
    channels = {}
    programmes = []
    # iterparse keeps memory bounded for guides with many programmes.
    for _, element in ET.iterparse(io.BytesIO(data), events=("end",)):
        if element.tag == "channel":
            channels[element.get("id", "")] = _preferred_text(element, "display-name")
            element.clear()
        elif element.tag == "programme":
            start = xmltv_time(element.get("start"))
            stop = xmltv_time(element.get("stop"))
            if start and start < end_window and (stop or start + timedelta(hours=2)) > start_window:
                title = _preferred_text(element, "title")
                if title:
                    categories = [(node.text or "").strip() for node in element.findall("category")]
                    programmes.append({
                        "channel_id": element.get("channel", ""),
                        "title": title,
                        "start": start.isoformat(),
                        "stop": stop.isoformat() if stop else "",
                        "kind": kind_for(categories),
                        "description": _preferred_text(element, "desc"),
                    })
            element.clear()
    for programme in programmes:
        programme["channel"] = channels.get(programme["channel_id"], programme["channel_id"])
    programmes.sort(key=lambda item: (datetime.fromisoformat(item["start"]), item["channel"].casefold()))
    return programmes
