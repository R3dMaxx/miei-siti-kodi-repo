MEDIAHUB ITALIA - versione 0.1.7

Installazione in Kodi:
1. Impostazioni > Sistema > Add-on > abilita "Sorgenti sconosciute" se necessario.
2. Add-on > Installa da un file zip.
3. Seleziona plugin.video.miei_siti-0.1.7.zip.
4. Apri Add-on video > MediaHub Italia.

Funzioni attuali:
- "Cosa guardo?" > "Stasera in TV": guida serale italiana gia' impostata,
  con schede per film, serie e altri programmi. Non serve inserire un URL.
- Fonte predefinita: https://epgshare01.online/epgshare01/epg_ripper_IT1.xml.gz
  Se la fonte non risponde, viene provata la guida alternativa
  https://www.open-epg.com/files/italy3.xml.gz (senza categorie Film/Serie).
- Per usare una fonte personale, scegli "Imposta una guida TV personale" e
  inserisci l'URL diretto di un file .xml o .xml.gz. "Ripristina" torna alla
  guida integrata. La guida puo' elencare anche canali non presenti
  nelle tue liste M3U; la scheda e' informativa e non avvia il canale.
- I dati della guida sono aggiornati al massimo ogni 6 ore e memorizzati
  solo per la serata corrente nella cartella dati dell'addon.
- Elenco dei canali Rakuten TV Live gratuiti disponibili per l'Italia.
- Categorie, quando restituite dall'API.
- Riproduzione tramite URL HLS fornito dal servizio al momento della selezione.
- Sezione YouTube con Film&More, Movies in Action, FilmRari, Moviedome IT e CineMadame.
- Elenco degli upload pubblici e playback YouTube delegati a plugin.video.youtube.
- Liste M3U online o locali per TV in chiaro, radio e VOD.
- TV Italia tramite la raccolta Forgejo peppenamir/iptv_italia.
- TV Italia - Tundrak con le varianti Essenziale e Completa.
- Radio Italia tramite la raccolta Tundrak/IPTV-Italia.
- Gestione delle liste personali direttamente da Kodi: aggiunta, modifica ed eliminazione.
- Supporto per gruppi, loghi, numerazione e header HTTP definiti nella playlist.

Limiti:
- La copertura dei canali, le categorie e gli orari dipendono dalla guida
  XMLTV scelta. Se film e serie non sono classificati, usa "Tutti i programmi".
- L'aggiornamento dalle fonti pubbliche richiede una connessione Internet;
  contenuti e disponibilita' sono gestiti dai rispettivi fornitori.
- Non sono ancora inclusi ricerca unificata, piattaforme streaming, titoli
  seguiti e calendario delle nuove uscite: sono previsti in versioni future.
- Nessun accesso a noleggio/acquisto/Videoteca.
- Nessun aggiramento DRM o autenticazione.
- L'API Rakuten TV non e' documentata pubblicamente e puo' cambiare.
- Cataloghi e playback possono dipendere dalla posizione geografica.
- YouTube richiede l'addon plugin.video.youtube installato; l'elenco degli upload
  pubblici non richiede una API key personale.
- Le liste predefinite sono lette dai progetti peppenamir/iptv_italia e
  Tundrak/IPTV-Italia e non sono incluse nel pacchetto. Disponibilita' e
  funzionamento dipendono dalle sorgenti.
- Non sono supportati portali Xtream, credenziali o contenuti protetti da DRM.

Compatibilita': Kodi 21.2 Omega (Python 3).

Novita 0.1.7:
- Guida italiana preimpostata EPGShare IT1, verificata il 28/09/2026 con
  programmi della serata e categorie Film/Fiction. Guida alternativa Open-EPG.
- Le impostazioni della vecchia fonte TVIT consigliata per 0.1.6 passano
  automaticamente alla guida preimpostata; altre fonti personali restano.
- Messaggi distinti quando mancano categorie o programmi per la serata.

Novita 0.1.6:
- Prima versione di "Cosa guardo?" con guida serale XMLTV, categorie e schede.
- Sorgente guida configurabile e cache limitata nel tempo.

Novita 0.1.5:
- Aggiunta TV Italia basata sulla lista Forgejo.
- Aggiunto il sottomenu TV Italia - Tundrak con le versioni Essenziale e Completa.
- Rinominato il collegamento radio in Radio Italia.
- Restano disponibili liste personali tramite URL web/cloud diretto o file locale.

Novita 0.1.4:
- Nuovo nome visibile MediaHub Italia; l'ID tecnico resta invariato per gli aggiornamenti.
- Nuova icona ad alta leggibilita' per TV.
- Rimossa completamente l'integrazione Pluto TV.
- Aggiunte liste M3U online/locali, preset IPTV-Italia e gestione sorgenti personali.
- Mantenute le integrazioni Rakuten TV e YouTube gia' funzionanti.

Novita 0.1.3:
- I canali YouTube aprono direttamente la playlist pubblica degli upload senza API key.
- Mantenuta invariata l'integrazione Rakuten TV della versione 0.1.1.

Novita 0.1.2:
- Aggiunti cinque canali pubblici nella sezione YouTube.
- Mantenuta invariata l'integrazione Rakuten TV della versione 0.1.1.

Novita 0.1.1:
- Rimossa la richiesta fissa per_page=100, ora rifiutata dall API Rakuten.
- Aggiunta paginazione robusta con fallback sui page size accettati.
- Migliorati logging e messaggi di errore HTTP.
