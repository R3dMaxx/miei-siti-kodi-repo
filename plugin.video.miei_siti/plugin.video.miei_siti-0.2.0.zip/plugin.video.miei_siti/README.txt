MEDIAHUB ITALIA - versione 0.2.0

Installazione in Kodi:
1. Impostazioni > Sistema > Add-on > abilita "Sorgenti sconosciute" se necessario.
2. Add-on > Installa da un file zip.
3. Seleziona plugin.video.miei_siti-0.2.0.zip.
4. Apri Add-on video > MediaHub Italia.

Funzioni attuali:
- "Cosa guardo?" > "Cerca film e serie TV": ricerca di titoli e schede in
  italiano, con locandina, trama, anno, generi, durata/stagioni e servizi
  disponibili per l'Italia, distinti tra abbonamento, gratis, pubblicita',
  noleggio e acquisto. I risultati sono paginati.
- "In arrivo al cinema in Italia": uscite italiane nei prossimi 60 giorni
  registrate in TMDb, incluse le uscite limitate, ordinate per data e paginate.
  La stella evidenzia i titoli seguiti, se il nome coincide con quello salvato.
- Per attivare queste due funzioni serve un account TMDb personale: nelle
  impostazioni dell'account TMDb, sezione API, richiedi la chiave per uso non
  commerciale e copia la voce "API Read Access Token". Nell'addon scegli
  "Cosa guardo?" > "[Imposta token TMDb]" e incollala. La maschera nasconde
  l'input, e il token e' salvato solo nei dati locali del profilo Kodi, mai
  nel file ZIP o nell'URL delle richieste. Non condividerlo in chat.
- "Cosa guardo?" > "Film stasera" / "Serie TV stasera": due elenchi
  distinti dalla guida serale italiana gia' impostata. Non serve un URL.
- Le schede mostrano, quando presenti, anno, paese, genere, regia e cast;
  le serie TV della guida mostrano stagione, episodio e titolo della puntata. La numerazione
  S/E compare anche nell'elenco quando la guida la fornisce.
- "Seguiti": pressione prolungata del tasto OK su un film o una serie,
  poi "Segui questo titolo". La sezione mostra i successivi passaggi
  disponibili nella guida italiana; dal menu contestuale puoi rimuovere
  il titolo. La lista dei seguiti rimane salvata tra gli aggiornamenti.
- Fonte predefinita: https://epgshare01.online/epgshare01/epg_ripper_IT1.xml.gz
  Se la fonte non risponde, viene provata la guida alternativa
  https://www.open-epg.com/files/italy3.xml.gz (senza categorie Film/Serie).
- Per usare una fonte personale, scegli "Imposta una guida TV personale" e
  inserisci l'URL diretto di un file .xml o .xml.gz. "Ripristina" torna alla
  guida integrata. La guida puo' elencare anche canali non presenti
  nelle tue liste M3U; la scheda e' informativa e non avvia il canale.
- I dati della guida sono aggiornati al massimo ogni 6 ore e memorizzati
  solo per la serata corrente nella cartella dati dell'addon.
- Elenco dei canali Rakuten TV Live gratuiti disponibili per l'Italia.
- Categorie, quando restituite dall'API.
- Riproduzione tramite URL HLS fornito dal servizio al momento della selezione.
- Sezione YouTube con Film&More, Movies in Action, FilmRari, Moviedome IT e CineMadame.
- Elenco degli upload pubblici e playback YouTube delegati a plugin.video.youtube.
- Liste M3U online o locali per TV in chiaro, radio e VOD.
- TV Italia tramite la raccolta Forgejo peppenamir/iptv_italia.
- TV Italia - Tundrak con le varianti Essenziale e Completa.
- Radio Italia tramite la raccolta Tundrak/IPTV-Italia.
- Gestione delle liste personali direttamente da Kodi: aggiunta, modifica ed eliminazione.
- Supporto per gruppi, loghi, numerazione e header HTTP definiti nella playlist.

Limiti:
- Le uscite al cinema dipendono dalle registrazioni TMDb: il calendario puo'
  essere incompleto o cambiare. Le date delle future premiere streaming non
  sono indicate come italiane senza una fonte affidabile specifica. La
  disponibilita' degli abbonamenti e' informativa e puo' cambiare.
- La copertura dei canali, le categorie e gli orari dipendono dalla guida
  XMLTV scelta. Se film e serie non sono classificati, usa "Tutti i programmi".
- L'aggiornamento dalle fonti pubbliche richiede una connessione Internet;
  contenuti e disponibilita' sono gestiti dai rispettivi fornitori.
- La guida TV gratuita copre solo i prossimi giorni; la ricerca TMDb e le
  piattaforme non avviano i cataloghi protetti dei servizi in abbonamento.
- Nessun accesso a noleggio/acquisto/Videoteca.
- Nessun aggiramento DRM o autenticazione.
- L'API Rakuten TV non e' documentata pubblicamente e puo' cambiare.
- Cataloghi e playback possono dipendere dalla posizione geografica.
- YouTube richiede l'addon plugin.video.youtube installato; l'elenco degli upload
  pubblici non richiede una API key personale.
- Le liste predefinite sono lette dai progetti peppenamir/iptv_italia e
  Tundrak/IPTV-Italia e non sono incluse nel pacchetto. Disponibilita' e
  funzionamento dipendono dalle sorgenti.
- Non sono supportati portali Xtream, credenziali o contenuti protetti da DRM.

Compatibilita': Kodi 21.2 Omega (Python 3).

Crediti:
- Film, serie, immagini e date di uscita: TMDb (The Movie Database).
  Questo prodotto usa l'API TMDb ma non e' approvato ne' certificato da TMDb.
  This product uses the TMDB API but is not endorsed or certified by TMDB.
  https://www.themoviedb.org
- Dati delle offerte italiane: JustWatch tramite TMDb. Verificare le offerte
  sul sito del fornitore prima di abbonarsi o acquistare.
- Logo TMDb approvato nella sezione Crediti dell'addon; il logo principale
  dell'addon resta MediaHub Italia.

Novita 0.2.0:
- Ricerca di film e serie TV con scheda italiana e offerte IT per tipologia.
- Uscite cinematografiche italiane nei prossimi 60 giorni con paginazione.
- Token TMDb locale, input nascosto; crediti TMDb e JustWatch.

Novita 0.1.9:
- Elenco persistente "Seguiti" per film e serie TV.
- Prossimi passaggi TV ricavati dalla guida disponibile, con data e canale.
- Menu contestuale per seguire o smettere di seguire un titolo.

Novita 0.1.8:
- Sezioni separate per Film e Serie TV, verificate sulla guida italiana.
- Schede piu' ricche con metadati disponibili nel file XMLTV.
- La cache della precedente versione e' rigenerata per includere i nuovi dati.

Novita 0.1.7:
- Guida italiana preimpostata EPGShare IT1, verificata il 28/09/2026 con
  programmi della serata e categorie Film/Fiction. Guida alternativa Open-EPG.
- Le impostazioni della vecchia fonte TVIT consigliata per 0.1.6 passano
  automaticamente alla guida preimpostata; altre fonti personali restano.
- Messaggi distinti quando mancano categorie o programmi per la serata.

Novita 0.1.6:
- Prima versione di "Cosa guardo?" con guida serale XMLTV, categorie e schede.
- Sorgente guida configurabile e cache limitata nel tempo.

Novita 0.1.5:
- Aggiunta TV Italia basata sulla lista Forgejo.
- Aggiunto il sottomenu TV Italia - Tundrak con le versioni Essenziale e Completa.
- Rinominato il collegamento radio in Radio Italia.
- Restano disponibili liste personali tramite URL web/cloud diretto o file locale.

Novita 0.1.4:
- Nuovo nome visibile MediaHub Italia; l'ID tecnico resta invariato per gli aggiornamenti.
- Nuova icona ad alta leggibilita' per TV.
- Rimossa completamente l'integrazione Pluto TV.
- Aggiunte liste M3U online/locali, preset IPTV-Italia e gestione sorgenti personali.
- Mantenute le integrazioni Rakuten TV e YouTube gia' funzionanti.

Novita 0.1.3:
- I canali YouTube aprono direttamente la playlist pubblica degli upload senza API key.
- Mantenuta invariata l'integrazione Rakuten TV della versione 0.1.1.

Novita 0.1.2:
- Aggiunti cinque canali pubblici nella sezione YouTube.
- Mantenuta invariata l'integrazione Rakuten TV della versione 0.1.1.

Novita 0.1.1:
- Rimossa la richiesta fissa per_page=100, ora rifiutata dall API Rakuten.
- Aggiunta paginazione robusta con fallback sui page size accettati.
- Migliorati logging e messaggi di errore HTTP.
