# -*- coding: utf-8 -*-
"""Small TMDB client and formatting helpers; credentials never enter URLs."""
from datetime import datetime, timedelta
import json
import urllib.error
import urllib.parse
import urllib.request

API_BASE = "https://api.themoviedb.org/3"
IMAGE_BASE = "https://image.tmdb.org/t/p/w342"


class TMDBError(RuntimeError):
    def __init__(self, message, status=None):
        self.status = status
        super().__init__(message)


def request(token, path, params=None):
    if not token or not path.startswith("/"):
        raise TMDBError("Token TMDb mancante o percorso non valido")
    url = API_BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        "Authorization": "Bearer " + token,
        "Accept": "application/json",
        "User-Agent": "MediaHub-Italia/0.2.0 (Kodi)",
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            raise TMDBError("Token TMDb non valido; inserisci l'API Read Access Token.", 401) from exc
        if exc.code == 429:
            raise TMDBError("Troppe richieste a TMDb; riprova tra poco.", 429) from exc
        raise TMDBError("TMDb non disponibile (HTTP %s)." % exc.code, exc.code) from exc
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        raise TMDBError("Impossibile raggiungere TMDb o leggere la risposta.") from exc


def search(token, kind, query, page=1):
    if kind not in ("movie", "tv"):
        raise ValueError("Tipo non valido")
    return request(token, "/search/" + kind, {
        "query": query, "language": "it-IT", "include_adult": "false", "page": page,
    })


def cinema(token, start, days=60, page=1):
    end = start + timedelta(days=days)
    return request(token, "/discover/movie", {
        "language": "it-IT", "region": "IT", "with_release_type": "2|3",
        "release_date.gte": start.isoformat(), "release_date.lte": end.isoformat(),
        "sort_by": "release_date.asc", "include_adult": "false", "page": page,
    })


def detail(token, kind, media_id):
    if kind not in ("movie", "tv") or not str(media_id).isdigit():
        raise ValueError("Titolo non valido")
    return request(token, "/%s/%s" % (kind, media_id), {"language": "it-IT"})


def providers(token, kind, media_id):
    if kind not in ("movie", "tv") or not str(media_id).isdigit():
        raise ValueError("Titolo non valido")
    data = request(token, "/%s/%s/watch/providers" % (kind, media_id))
    return (data.get("results") or {}).get("IT") or {}


def poster(path):
    return IMAGE_BASE + path if isinstance(path, str) and path.startswith("/") else ""


def title(data, kind):
    return data.get("title" if kind == "movie" else "name") or data.get("original_title" if kind == "movie" else "original_name") or "Senza titolo"


def year(data, kind):
    return (data.get("release_date" if kind == "movie" else "first_air_date") or "")[:4]


def provider_names(italy, category):
    entries = italy.get(category) or []
    return ", ".join(dict.fromkeys(p["provider_name"] for p in entries if p.get("provider_name")))


def italian_date(raw):
    try:
        return datetime.strptime(raw[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
    except (TypeError, ValueError):
        return raw or "data non indicata"
