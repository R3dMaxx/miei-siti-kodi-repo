MEDIAHUB ITALIA - versione 0.2.4 (Kodi 21.2 Omega)

CHE COS'E'
MediaHub Italia aiuta a scegliere cosa guardare e riunisce alcune fonti
video in Kodi: schede di film e serie, offerte disponibili in Italia,
uscite cinematografiche, guida TV, titoli seguiti e canali gratuiti.
Le date e le offerte dipendono dalle fonti e possono cambiare.

INSTALLAZIONE
Kodi > Add-on > Installa da un file ZIP > plugin.video.miei_siti-0.2.4.zip.
Se richiesto, abilita prima Impostazioni > Sistema > Add-on > Sorgenti sconosciute.
Gli aggiornamenti conservano codice TMDb, guida TV e liste personali nel
profilo locale dell'add-on: non sono inclusi nello ZIP.

MENU PRINCIPALE
- Cerca film e serie: ricerca TMDb; la scheda del titolo mostra trama,
  anno e offerte italiane di abbonamento, gratis, noleggio e acquisto.
- In arrivo: film al cinema in Italia nei prossimi 60 giorni (TMDb);
  serie TV e film futuri in streaming in Italia (pagine JustWatch esterne).
  Su Android queste pagine si aprono nel browser; altrove viene mostrato
  l'indirizzo. I titoli seguiti non sono evidenziati sul sito esterno.
- Stasera in TV: elenchi Film e Serie TV ricavati dalla guida XMLTV;
  stagione ed episodio compaiono quando la fonte li fornisce.
- Titoli seguiti: elenco personale e futuri passaggi nella guida TV.
  Per seguire un titolo tieni premuto OK sulla scheda e scegli il comando.
- Canali e liste: Rakuten Live gratuito, canali YouTube selezionati,
  liste TV/Radio Italia preimpostate e liste M3U personali.
- Impostazioni e fonti: codice TMDb, guida TV, spiegazioni e crediti.

Le voci dei menu hanno descrizioni e piccole icone. Dal menu contestuale
('tieni premuto OK') scegli 'Cosa fa questa voce?' per leggere la
spiegazione; la schermata 'Che cos'e MediaHub Italia' illustra l'insieme.

CODICE TMDB
In Impostazioni e fonti > Inserisci/Cambia il codice TMDb, incolla la
'API Key' breve oppure 'API Read Access Token' lungo. Il codice viene
verificato con una richiesta a TMDb prima del salvataggio. Non inserire
email o password e non condividere il codice in chat. La chiave breve e'
inviata a TMDb nell'URL di una richiesta HTTPS, quella lunga nell'header.

GUIDA TV
La fonte italiana predefinita e':
https://epgshare01.online/epgshare01/epg_ripper_IT1.xml.gz
Fonte alternativa: https://www.open-epg.com/files/italy3.xml.gz
Puoi impostare una guida personale XML o XML.GZ da Impostazioni e fonti.
La guida puo' elencare canali non presenti nelle liste M3U: la sua scheda
e' informativa. Le categorie Film e Serie TV dipendono dai dati XMLTV.

FONTI E LIMITI
TMDb fornisce schede, immagini e date dei film al cinema. Le disponibilita'
italiane nelle schede provengono da JustWatch tramite TMDb. Le pagine
JustWatch sulle future uscite in streaming vengono aperte nel browser:
non sono copiate nell'add-on e non applicano il filtro locale di 60 giorni.
Questo prodotto usa l'API TMDb ma non e' approvato ne' certificato da TMDb.
This product uses the TMDB API but is not endorsed or certified by TMDB.
https://www.themoviedb.org - https://www.justwatch.com/it

I canali gratuiti e le liste M3U dipendono dai rispettivi fornitori.
La sezione YouTube usa plugin.video.youtube. I cataloghi protetti da DRM
di Netflix, Prime Video e altri servizi non si riproducono nell'add-on.
