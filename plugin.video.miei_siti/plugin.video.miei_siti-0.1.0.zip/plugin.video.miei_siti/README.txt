I MIEI SITI - versione 0.1.0

Installazione in Kodi:
1. Impostazioni > Sistema > Add-on > abilita "Sorgenti sconosciute" se necessario.
2. Add-on > Installa da un file zip.
3. Seleziona plugin.video.miei_siti-0.1.0.zip.
4. Apri Add-on video > I miei siti > Rakuten TV.

Funzioni attuali:
- Elenco dei canali Rakuten TV Live gratuiti disponibili per l'Italia.
- Categorie, quando restituite dall'API.
- Riproduzione tramite URL HLS fornito dal servizio al momento della selezione.

Limiti:
- Nessun accesso a noleggio/acquisto/Videoteca.
- Nessun aggiramento DRM o autenticazione.
- L'API Rakuten TV non e' documentata pubblicamente e puo' cambiare.

Compatibilita': Kodi con Python 3 (Kodi 19+).
