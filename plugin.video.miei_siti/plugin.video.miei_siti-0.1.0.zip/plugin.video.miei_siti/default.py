# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import sys
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

API_BASE = "https://gizmo.rakuten.tv/v3"
MARKET = "it"
LOCALE = "it"
CLASSIFICATION_ID = 36

HEADERS = {
    "Origin": "https://www.rakuten.tv",
    "Referer": "https://www.rakuten.tv/it",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0 Safari/537.36"
    ),
    "Accept": "application/json",
}


def notify(message, title="I miei siti"):
    xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, 5000)


def api_request(path, method="GET", params=None, payload=None):
    params = params or {}
    query = urllib.parse.urlencode(params)
    url = API_BASE + path + ("?" + query if query else "")
    headers = dict(HEADERS)
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        xbmc.log("[I miei siti] HTTP %s: %s" % (exc.code, body), xbmc.LOGERROR)
        raise
    except Exception as exc:
        xbmc.log("[I miei siti] API error: %s" % exc, xbmc.LOGERROR)
        raise


def rakuten_params():
    return {
        "classification_id": CLASSIFICATION_ID,
        "device_identifier": "web",
        "locale": LOCALE,
        "market_code": MARKET,
    }


def get_channels():
    params = rakuten_params()
    params.update({"page": 1, "per_page": 100})
    result = api_request("/live_channels", params=params)
    return result.get("data", []) or []


def get_categories():
    result = api_request("/live_channel_categories", params=rakuten_params())
    return result.get("data", []) or []


def build_url(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def add_folder(label, **kwargs):
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**kwargs), item, True)


def add_playable(label, channel_id, plot="", art=None):
    item = xbmcgui.ListItem(label=label)
    item.setProperty("IsPlayable", "true")
    try:
        item.setInfo("video", {"title": label, "plot": plot})
    except Exception:
        pass
    if art:
        item.setArt(art)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(mode="play", channel_id=channel_id),
        item,
        False,
    )


def channel_image(channel):
    # L'API ha cambiato nel tempo i nomi dei campi immagini: proviamo i più comuni.
    candidates = []
    for key in ("images", "image", "artwork", "artworks"):
        value = channel.get(key)
        if isinstance(value, dict):
            candidates.extend(value.values())
        elif isinstance(value, list):
            candidates.extend(value)
        elif isinstance(value, str):
            candidates.append(value)
    for value in candidates:
        if isinstance(value, dict):
            for k in ("url", "src", "original", "medium", "large"):
                if isinstance(value.get(k), str) and value[k].startswith("http"):
                    return value[k]
        elif isinstance(value, str) and value.startswith("http"):
            return value
    return ""


def categories_map():
    mapping = {}
    categories = get_categories()
    for category in categories:
        name = category.get("name") or category.get("title") or "Altro"
        ids = category.get("live_channels", []) or []
        for channel_id in ids:
            if isinstance(channel_id, dict):
                channel_id = channel_id.get("id")
            if channel_id:
                mapping[str(channel_id)] = name
    return categories, mapping


def root():
    xbmcplugin.setPluginCategory(HANDLE, "I miei siti")
    add_folder("Rakuten TV", mode="rakuten")
    xbmcplugin.endOfDirectory(HANDLE)


def rakuten_root():
    xbmcplugin.setPluginCategory(HANDLE, "Rakuten TV")
    add_folder("Tutti i canali Live gratuiti", mode="channels")
    try:
        categories = get_categories()
        for category in categories:
            name = category.get("name") or category.get("title")
            if name:
                add_folder(name, mode="channels", category=name)
    except Exception:
        # Se l'endpoint categorie non risponde, l'elenco completo resta comunque disponibile.
        pass
    add_folder("Informazioni / limiti", mode="info")
    xbmcplugin.endOfDirectory(HANDLE)


def list_channels(category=None):
    xbmcplugin.setPluginCategory(HANDLE, "Rakuten TV - Live")
    try:
        channels = get_channels()
        mapping = {}
        if category:
            try:
                _, mapping = categories_map()
            except Exception:
                mapping = {}

        shown = 0
        for channel in channels:
            channel_id = str(channel.get("id", ""))
            if not channel_id:
                continue
            if category and mapping.get(channel_id) != category:
                continue

            title = channel.get("title") or channel.get("name") or channel_id
            description = channel.get("description") or channel.get("short_description") or ""
            image = channel_image(channel)
            art = {"thumb": image, "poster": image, "icon": image} if image else None
            add_playable(title, channel_id, description, art)
            shown += 1

        if shown == 0:
            notify("Nessun canale restituito per questa sezione.")
        xbmcplugin.setContent(HANDLE, "videos")
    except Exception:
        notify("Impossibile recuperare i canali Rakuten TV. Consulta il log di Kodi.")
    xbmcplugin.endOfDirectory(HANDLE)


def find_channel(channel_id):
    for channel in get_channels():
        if str(channel.get("id", "")) == str(channel_id):
            return channel
    return None


def first_language_id(channel):
    labels = channel.get("labels", {}) if isinstance(channel, dict) else {}
    languages = labels.get("languages", []) if isinstance(labels, dict) else []
    for language in languages:
        if isinstance(language, dict) and language.get("id"):
            return language["id"]
    return "MIS"


def play_channel(channel_id):
    try:
        channel = find_channel(channel_id)
        if not channel:
            raise RuntimeError("Canale non trovato")

        params = rakuten_params()
        params.update({
            "device_stream_audio_quality": "2.0",
            "device_stream_hdr_type": "NONE",
            "device_stream_video_quality": "FHD",
            "disable_dash_legacy_packages": "false",
        })
        payload = {
            "audio_language": first_language_id(channel),
            "audio_quality": "2.0",
            "classification_id": CLASSIFICATION_ID,
            "content_id": channel_id,
            "content_type": "live_channels",
            "device_serial": "kodi-personal-addon",
            "player": "web:HLS-NONE:NONE",
            "strict_video_quality": False,
            "subtitle_language": "MIS",
            "video_type": "stream",
        }

        result = api_request("/avod/streamings", method="POST", params=params, payload=payload)
        infos = (result.get("data", {}) or {}).get("stream_infos", []) or []
        if not infos:
            raise RuntimeError("Rakuten non ha restituito uno stream")

        stream_url = infos[0].get("url")
        if not stream_url:
            raise RuntimeError("URL stream assente")

        # Manteniamo l'URL restituito dal servizio senza manipolare DRM o token.
        item = xbmcgui.ListItem(path=stream_url)
        item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    except Exception as exc:
        xbmc.log("[I miei siti] playback error: %s" % exc, xbmc.LOGERROR)
        notify("Riproduzione non disponibile per questo canale.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def show_info():
    text = (
        "Rakuten TV - integrazione personale\n\n"
        "Questa versione usa gli endpoint del servizio per elencare e riprodurre "
        "i canali Live gratuiti disponibili per il mercato italiano.\n\n"
        "Non gestisce acquisti, noleggi, account o contenuti VOD protetti da DRM. "
        "Non rimuove né aggira protezioni.\n\n"
        "Sito ufficiale: https://www.rakuten.tv/it\n\n"
        "Se Rakuten modifica le proprie API, alcune funzioni potrebbero richiedere un aggiornamento dell'addon."
    )
    xbmcgui.Dialog().textviewer("Rakuten TV", text)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def router():
    query = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 and sys.argv[2] else {}
    mode = query.get("mode", [""])[0]

    if not mode:
        root()
    elif mode == "rakuten":
        rakuten_root()
    elif mode == "channels":
        list_channels(query.get("category", [None])[0])
    elif mode == "play":
        play_channel(query.get("channel_id", [""])[0])
    elif mode == "info":
        show_info()
    else:
        root()


if __name__ == "__main__":
    router()
