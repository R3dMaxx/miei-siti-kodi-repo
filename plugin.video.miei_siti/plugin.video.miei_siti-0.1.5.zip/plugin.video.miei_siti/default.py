# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import re
import sys
import urllib.parse
import urllib.request
import urllib.error
import uuid

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

API_BASE = "https://gizmo.rakuten.tv/v3"
MARKET = "it"
LOCALE = "it"
CLASSIFICATION_ID = 36

HEADERS = {
    "Origin": "https://www.rakuten.tv",
    "Referer": "https://www.rakuten.tv/it",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0 Safari/537.36"
    ),
    "Accept": "application/json",
}

ADDON_NAME = "MediaHub Italia"
ADDON_ID = "plugin.video.miei_siti"
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
SOURCES_FILE = DATA_DIR.rstrip("/\\") + "/sources.json"
MAX_PLAYLIST_BYTES = 5 * 1024 * 1024
MAX_PLAYLIST_ITEMS = 5000

M3U_PRESETS = {
    "tv_italia": {
        "id": "tv_italia",
        "name": "TV Italia",
        "location": "https://forgejo.it/peppenamir/iptv_italia/raw/branch/main/lista.m3u",
        "kind": "url",
        "media_type": "tv",
        "preset": True,
    },
    "tundrak_basic": {
        "id": "tundrak_basic",
        "name": "TV Italia - Essenziale",
        "location": "https://github.com/Tundrak/IPTV-Italia/raw/main/iptvita.m3u",
        "kind": "url",
        "media_type": "tv",
        "preset": True,
    },
    "tundrak_plus": {
        "id": "tundrak_plus",
        "name": "TV Italia - Completa",
        "location": "https://github.com/Tundrak/IPTV-Italia/raw/main/iptvitaplus.m3u",
        "kind": "url",
        "media_type": "tv",
        "preset": True,
    },
    "iptvita_radio": {
        "id": "iptvita_radio",
        "name": "IPTV Italia - Radio",
        "location": "https://github.com/Tundrak/IPTV-Italia/raw/main/ipradioita.m3u",
        "kind": "url",
        "media_type": "radio",
        "preset": True,
    },
}

YOUTUBE_CHANNELS = (
    ("Film&More", "UC2DWplnIpAtu9OWgH9-ZVrQ"),
    ("Movies in Action", "UCyzV93S6FKWPNtbxvl2DmJQ"),
    ("FilmRari", "UCzLtrdBKjZIBcs8aWR06Yuw"),
    ("Moviedome IT", "UC4rMaEpZKmKwQJHtMUi3IaA"),
    ("CineMadame", "UCG6uomZkstGuNLwGmYMLbJw"),
)


def notify(message, title=ADDON_NAME):
    xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, 5000)


class ApiHttpError(RuntimeError):
    def __init__(self, code, body=""):
        self.code = code
        self.body = body or ""
        super().__init__("HTTP %s: %s" % (code, self.body[:300]))


def api_request(path, method="GET", params=None, payload=None):
    params = params or {}
    query = urllib.parse.urlencode(params)
    url = API_BASE + path + ("?" + query if query else "")
    headers = dict(HEADERS)
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        xbmc.log("[MediaHub Italia] HTTP %s: %s" % (exc.code, body), xbmc.LOGERROR)
        raise ApiHttpError(exc.code, body) from exc
    except Exception as exc:
        xbmc.log("[MediaHub Italia] API error: %s" % exc, xbmc.LOGERROR)
        raise


def rakuten_params():
    return {
        "classification_id": CLASSIFICATION_ID,
        "device_identifier": "web",
        "locale": LOCALE,
        "market_code": MARKET,
    }


def _channel_page(page, per_page=None):
    params = rakuten_params()
    params["page"] = page
    if per_page is not None:
        params["per_page"] = per_page
    return api_request("/live_channels", params=params)


def _first_channel_page():
    # Rakuten ha iniziato a rifiutare per_page=100 con HTTP 400.
    # Preferiamo quindi il page size predefinito del servizio; se in futuro
    # diventasse obbligatorio, proviamo alcuni valori conservativi.
    try:
        return _channel_page(1, None), None
    except ApiHttpError as exc:
        if exc.code != 400:
            raise
        first_error = exc

    for candidate in (50, 25, 20, 10):
        try:
            result = _channel_page(1, candidate)
            xbmc.log(
                "[MediaHub Italia] Rakuten per_page accettato: %s" % candidate,
                xbmc.LOGINFO,
            )
            return result, candidate
        except ApiHttpError as exc:
            if exc.code == 400 and "invalid_per_page" in exc.body:
                continue
            raise

    raise first_error


def _pagination_last_page(result):
    # L'API non e' documentata: supportiamo i nomi piu' comuni senza
    # dipendere da una struttura specifica.
    candidates = []
    for key in ("meta", "pagination"):
        value = result.get(key)
        if isinstance(value, dict):
            candidates.append(value)
            nested = value.get("pagination")
            if isinstance(nested, dict):
                candidates.append(nested)

    for data in candidates:
        for key in ("total_pages", "last_page", "pages"):
            value = data.get(key)
            try:
                value = int(value)
            except (TypeError, ValueError):
                continue
            if value > 0:
                return value
    return None


def get_channels():
    first_result, per_page = _first_channel_page()
    channels = []
    seen_ids = set()
    page = 1
    result = first_result
    max_pages = 100

    while page <= max_pages:
        page_channels = result.get("data", []) or []
        if not isinstance(page_channels, list):
            raise RuntimeError("Formato inatteso nella risposta live_channels")
        if not page_channels:
            break

        new_items = 0
        for channel in page_channels:
            if not isinstance(channel, dict):
                continue
            channel_id = str(channel.get("id", ""))
            if channel_id and channel_id in seen_ids:
                continue
            if channel_id:
                seen_ids.add(channel_id)
            channels.append(channel)
            new_items += 1

        xbmc.log(
            "[MediaHub Italia] Rakuten live page %s: %s elementi (%s nuovi)"
            % (page, len(page_channels), new_items),
            xbmc.LOGINFO,
        )

        # Se la pagina e' interamente duplicata, evitiamo un loop nel caso
        # in cui Rakuten ignori il parametro page.
        if new_items == 0:
            break

        last_page = _pagination_last_page(result)
        if last_page is not None and page >= last_page:
            break

        page += 1
        result = _channel_page(page, per_page)

    if page > max_pages:
        xbmc.log(
            "[MediaHub Italia] Interrotta paginazione Rakuten al limite di %s pagine"
            % max_pages,
            xbmc.LOGWARNING,
        )

    return channels


def get_categories():
    result = api_request("/live_channel_categories", params=rakuten_params())
    return result.get("data", []) or []


def build_url(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def add_folder(label, **kwargs):
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**kwargs), item, True)


def add_external_folder(label, url):
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url, item, True)


def _ensure_data_dir():
    if not xbmcvfs.exists(DATA_DIR):
        xbmcvfs.mkdirs(DATA_DIR)


def load_custom_sources():
    if not xbmcvfs.exists(SOURCES_FILE):
        return []
    try:
        handle = xbmcvfs.File(SOURCES_FILE)
        raw = handle.read()
        handle.close()
        data = json.loads(raw or "[]")
        return [source for source in data if isinstance(source, dict)] if isinstance(data, list) else []
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Lettura sorgenti M3U fallita: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile leggere le sorgenti M3U salvate.")
        return []


def save_custom_sources(sources):
    _ensure_data_dir()
    handle = xbmcvfs.File(SOURCES_FILE, "w")
    handle.write(json.dumps(sources, ensure_ascii=False, indent=2))
    handle.close()


def get_m3u_source(source_id):
    if source_id in M3U_PRESETS:
        return dict(M3U_PRESETS[source_id])
    for source in load_custom_sources():
        if source.get("id") == source_id:
            return source
    return None


def _media_type_dialog(default="auto"):
    choices = (("auto", "Automatico"), ("tv", "TV in diretta"), ("radio", "Radio"), ("vod", "Video / VOD"))
    preselect = next((index for index, item in enumerate(choices) if item[0] == default), 0)
    selected = xbmcgui.Dialog().select("Tipo di contenuto", [item[1] for item in choices], preselect=preselect)
    return choices[selected][0] if selected >= 0 else None


def add_m3u_source(kind):
    dialog = xbmcgui.Dialog()
    if kind == "url":
        location = dialog.input("Indirizzo della lista M3U", defaultt="https://", type=xbmcgui.INPUT_ALPHANUM).strip()
        parsed = urllib.parse.urlparse(location)
        if not location or parsed.scheme not in ("http", "https"):
            if location:
                notify("Inserisci un indirizzo http:// o https:// valido.")
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return
    else:
        location = dialog.browseSingle(1, "Scegli una lista M3U", "files", ".m3u|.m3u8").strip()
        if not location:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return

    suggested = location.rstrip("/\\").rsplit("/", 1)[-1] or "La mia lista"
    name = dialog.input("Nome della lista", defaultt=suggested, type=xbmcgui.INPUT_ALPHANUM).strip()
    if not name:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    media_type = _media_type_dialog()
    if media_type is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return

    sources = load_custom_sources()
    sources.append({
        "id": uuid.uuid4().hex,
        "name": name,
        "location": location,
        "kind": kind,
        "media_type": media_type,
    })
    save_custom_sources(sources)
    notify("Lista M3U aggiunta: %s" % name)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def edit_m3u_source(source_id):
    source = get_m3u_source(source_id)
    if not source or source.get("preset"):
        notify("Questa sorgente non può essere modificata.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    dialog = xbmcgui.Dialog()
    name = dialog.input("Nome della lista", defaultt=source.get("name", ""), type=xbmcgui.INPUT_ALPHANUM).strip()
    if not name:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    location = source.get("location", "")
    if source.get("kind") == "url":
        location = dialog.input("Indirizzo della lista M3U", defaultt=location, type=xbmcgui.INPUT_ALPHANUM).strip()
        if urllib.parse.urlparse(location).scheme not in ("http", "https"):
            notify("Indirizzo non valido.")
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return
    else:
        replacement = dialog.browseSingle(1, "Scegli la lista M3U", "files", ".m3u|.m3u8", False, False, location)
        if replacement:
            location = replacement
    media_type = _media_type_dialog(source.get("media_type", "auto"))
    if media_type is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    sources = load_custom_sources()
    for item in sources:
        if item.get("id") == source_id:
            item.update({"name": name, "location": location, "media_type": media_type})
            break
    save_custom_sources(sources)
    notify("Lista M3U aggiornata.")
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def delete_m3u_source(source_id):
    source = get_m3u_source(source_id)
    if not source or source.get("preset"):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    if xbmcgui.Dialog().yesno(ADDON_NAME, "Eliminare la lista '%s'?" % source.get("name", "")):
        save_custom_sources([item for item in load_custom_sources() if item.get("id") != source_id])
        notify("Lista M3U eliminata.")
        xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def read_m3u_source(source):
    location = source.get("location", "")
    if source.get("kind") == "url":
        request = urllib.request.Request(location, headers={"User-Agent": HEADERS["User-Agent"], "Accept": "audio/x-mpegurl, application/vnd.apple.mpegurl, text/plain, */*"})
        raw = None
        for attempt in range(2):
            try:
                with urllib.request.urlopen(request, timeout=20) as response:
                    raw = response.read(MAX_PLAYLIST_BYTES + 1)
                break
            except urllib.error.HTTPError as exc:
                if attempt == 0 and 500 <= exc.code < 600:
                    xbmc.log("[MediaHub Italia] Errore HTTP %s, nuovo tentativo M3U" % exc.code, xbmc.LOGWARNING)
                    continue
                raise
        if len(raw) > MAX_PLAYLIST_BYTES:
            raise RuntimeError("La lista supera il limite di 5 MB")
        return raw.decode("utf-8-sig", errors="replace")
    handle = xbmcvfs.File(location)
    raw = handle.read(MAX_PLAYLIST_BYTES + 1)
    handle.close()
    if len(raw) > MAX_PLAYLIST_BYTES:
        raise RuntimeError("La lista supera il limite di 5 MB")
    if isinstance(raw, bytes):
        return raw.decode("utf-8-sig", errors="replace")
    return raw.lstrip("\ufeff")


def parse_m3u(text, base_location=""):
    entries = []
    pending = None
    attrs_pattern = re.compile(r'([\w-]+)\s*=\s*"([^"]*)"')
    for original in text.splitlines():
        line = original.strip()
        if not line:
            continue
        if line.upper().startswith("#EXTINF:"):
            payload = line.split(":", 1)[1]
            metadata, separator, title = payload.partition(",")
            attrs = {key.lower(): value for key, value in attrs_pattern.findall(metadata)}
            pending = {
                "title": title.strip() if separator else "",
                "group": attrs.get("group-title", "").strip(),
                "logo": attrs.get("tvg-logo", "").strip(),
                "channel": attrs.get("tvg-chno", "").strip(),
                "headers": {},
            }
            continue
        if pending is not None and line.upper().startswith("#EXTGRP:"):
            pending["group"] = line.split(":", 1)[1].strip()
            continue
        if pending is not None and line.upper().startswith("#EXTVLCOPT:"):
            option = line.split(":", 1)[1]
            key, separator, value = option.partition("=")
            if separator and key.lower() in ("http-user-agent", "http-referrer", "http-referer"):
                header = "User-Agent" if key.lower() == "http-user-agent" else "Referer"
                pending["headers"][header] = value.strip()
            continue
        if line.startswith("#"):
            continue
        if pending is None:
            pending = {"title": "", "group": "", "logo": "", "channel": "", "headers": {}}
        if base_location.startswith(("http://", "https://")):
            stream_url = urllib.parse.urljoin(base_location, line)
        else:
            stream_url = line
        parsed = urllib.parse.urlparse(stream_url.split("|", 1)[0])
        if parsed.scheme not in ("http", "https", "smb", "nfs", "special", "file") and not stream_url.startswith("/"):
            pending = None
            continue
        pending["url"] = stream_url
        pending["title"] = pending["title"] or stream_url.rsplit("/", 1)[-1] or "Senza titolo"
        entries.append(pending)
        pending = None
        if len(entries) >= MAX_PLAYLIST_ITEMS:
            break
    return entries


def m3u_root():
    xbmcplugin.setPluginCategory(HANDLE, "Liste M3U")
    add_folder("TV Italia", mode="m3u_source", source_id="tv_italia")
    add_folder("TV Italia - Tundrak", mode="m3u_tundrak")
    add_folder("Radio Italia", mode="m3u_source", source_id="iptvita_radio")
    for source in load_custom_sources():
        add_folder(source.get("name", "Lista senza nome"), mode="m3u_source", source_id=source.get("id", ""))
    add_folder("[Aggiungi lista da Internet]", mode="m3u_add", kind="url")
    add_folder("[Aggiungi lista da file]", mode="m3u_add", kind="file")
    add_folder("[Gestisci le mie liste]", mode="m3u_manage")
    add_folder("Informazioni / limiti", mode="m3u_info")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def m3u_tundrak_root():
    xbmcplugin.setPluginCategory(HANDLE, "TV Italia - Tundrak")
    add_folder("Essenziale", mode="m3u_source", source_id="tundrak_basic")
    add_folder("Completa", mode="m3u_source", source_id="tundrak_plus")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def m3u_manage():
    xbmcplugin.setPluginCategory(HANDLE, "Gestisci liste M3U")
    sources = load_custom_sources()
    if not sources:
        notify("Non hai ancora aggiunto liste personali.")
    for source in sources:
        source_id = source.get("id", "")
        add_folder("Modifica: %s" % source.get("name", "Lista"), mode="m3u_edit", source_id=source_id)
        add_folder("Elimina: %s" % source.get("name", "Lista"), mode="m3u_delete", source_id=source_id)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_m3u(source_id, group=None):
    source = get_m3u_source(source_id)
    if not source:
        notify("Sorgente M3U non trovata.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, source.get("name", "Lista M3U"))
    try:
        entries = parse_m3u(read_m3u_source(source), source.get("location", ""))
        groups = sorted({entry.get("group", "") for entry in entries if entry.get("group")}, key=str.casefold)
        if group is None and groups:
            add_folder("Tutti", mode="m3u_source", source_id=source_id, group="__all__")
            for name in groups:
                add_folder(name, mode="m3u_source", source_id=source_id, group=name)
        else:
            selected = entries if group in (None, "__all__") else [entry for entry in entries if entry.get("group") == group]
            for entry in selected:
                title = entry.get("title", "Senza titolo")
                if entry.get("channel"):
                    title = "%s · %s" % (entry["channel"], title)
                item = xbmcgui.ListItem(label=title)
                item.setProperty("IsPlayable", "true")
                media_type = source.get("media_type", "auto")
                info_kind = "music" if media_type == "radio" else "video"
                try:
                    item.setInfo(info_kind, {"title": entry.get("title", title), "genre": entry.get("group", "")})
                except Exception:
                    pass
                if entry.get("logo"):
                    item.setArt({"icon": entry["logo"], "thumb": entry["logo"]})
                xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="m3u_play", stream_url=entry["url"], headers=json.dumps(entry.get("headers", {})), media_type=media_type), item, False)
            xbmcplugin.setContent(HANDLE, "songs" if source.get("media_type") == "radio" else "videos")
        if not entries:
            notify("La lista non contiene elementi riproducibili.")
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Errore lista M3U: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile aprire la lista M3U. Consulta il log di Kodi.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def play_m3u(stream_url, headers_json="{}", media_type="auto"):
    try:
        headers = json.loads(headers_json or "{}")
        if not isinstance(headers, dict):
            headers = {}
        header_query = urllib.parse.urlencode(headers)
        playback_url = stream_url + (("&" if "|" in stream_url else "|") + header_query if header_query else "")
        item = xbmcgui.ListItem(path=playback_url)
        item.setProperty("IsPlayable", "true")
        clean_path = urllib.parse.urlparse(stream_url.split("|", 1)[0]).path.lower()
        if clean_path.endswith(".m3u8"):
            item.setMimeType("application/vnd.apple.mpegurl")
            item.setContentLookup(False)
        elif clean_path.endswith(".mpd"):
            item.setProperty("inputstream", "inputstream.adaptive")
            item.setProperty("inputstream.adaptive.manifest_type", "mpd")
            if header_query:
                item.setProperty("inputstream.adaptive.manifest_headers", header_query)
                item.setProperty("inputstream.adaptive.stream_headers", header_query)
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Playback M3U fallito: %s" % exc, xbmc.LOGERROR)
        notify("Riproduzione non disponibile.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def show_m3u_info():
    text = (
        "Liste M3U\n\nPuoi aprire le raccolte IPTV Italia oppure aggiungere liste "
        "personali tramite indirizzo Internet o file .m3u/.m3u8. Sono supportati "
        "canali TV, radio e VOD riproducibili direttamente da Kodi.\n\n"
        "Le raccolte predefinite sono lette dai progetti peppenamir/iptv_italia "
        "e Tundrak/IPTV-Italia: MediaHub Italia non ne copia né gestisce i contenuti.\n\n"
        "Non sono supportati portali Xtream, credenziali o aggiramenti DRM. "
        "Usa soltanto liste e flussi che sei autorizzato a riprodurre."
    )
    xbmcgui.Dialog().textviewer("Liste M3U", text)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def add_playable(label, channel_id, plot="", art=None):
    item = xbmcgui.ListItem(label=label)
    item.setProperty("IsPlayable", "true")
    try:
        item.setInfo("video", {"title": label, "plot": plot})
    except Exception:
        pass
    if art:
        item.setArt(art)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(mode="play", channel_id=channel_id),
        item,
        False,
    )


def channel_image(channel):
    # L'API ha cambiato nel tempo i nomi dei campi immagini: proviamo i più comuni.
    candidates = []
    for key in ("images", "image", "artwork", "artworks"):
        value = channel.get(key)
        if isinstance(value, dict):
            candidates.extend(value.values())
        elif isinstance(value, list):
            candidates.extend(value)
        elif isinstance(value, str):
            candidates.append(value)
    for value in candidates:
        if isinstance(value, dict):
            for k in ("url", "src", "original", "medium", "large"):
                if isinstance(value.get(k), str) and value[k].startswith("http"):
                    return value[k]
        elif isinstance(value, str) and value.startswith("http"):
            return value
    return ""


def categories_map():
    mapping = {}
    categories = get_categories()
    for category in categories:
        name = category.get("name") or category.get("title") or "Altro"
        ids = category.get("live_channels", []) or []
        for channel_id in ids:
            if isinstance(channel_id, dict):
                channel_id = channel_id.get("id")
            if channel_id:
                mapping[str(channel_id)] = name
    return categories, mapping


def root():
    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    add_folder("Rakuten TV", mode="rakuten")
    add_folder("YouTube", mode="youtube")
    add_folder("Liste M3U", mode="m3u")
    xbmcplugin.endOfDirectory(HANDLE)


def youtube_root():
    xbmcplugin.setPluginCategory(HANDLE, "YouTube")
    for label, channel_id in YOUTUBE_CHANNELS:
        # La pagina canale richiede YouTube Data API per ricavare la playlist
        # degli upload. Il relativo ID e' invece deterministico: prefisso UU
        # seguito dal Channel ID senza UC. Aprendo direttamente tale playlist,
        # plugin.video.youtube 7.4.4 usa il proprio fallback pubblico e non
        # richiede una API key personale per mostrare i video.
        uploads_playlist_id = "UU" + channel_id[2:]
        add_external_folder(
            label,
            "plugin://plugin.video.youtube/playlist/%s/" % uploads_playlist_id,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def rakuten_root():
    xbmcplugin.setPluginCategory(HANDLE, "Rakuten TV")
    add_folder("Tutti i canali Live gratuiti", mode="channels")
    try:
        categories = get_categories()
        for category in categories:
            name = category.get("name") or category.get("title")
            if name:
                add_folder(name, mode="channels", category=name)
    except Exception:
        # Se l'endpoint categorie non risponde, l'elenco completo resta comunque disponibile.
        pass
    add_folder("Informazioni / limiti", mode="info")
    xbmcplugin.endOfDirectory(HANDLE)


def list_channels(category=None):
    xbmcplugin.setPluginCategory(HANDLE, "Rakuten TV - Live")
    try:
        channels = get_channels()
        mapping = {}
        if category:
            try:
                _, mapping = categories_map()
            except Exception:
                mapping = {}

        shown = 0
        for channel in channels:
            channel_id = str(channel.get("id", ""))
            if not channel_id:
                continue
            if category and mapping.get(channel_id) != category:
                continue

            title = channel.get("title") or channel.get("name") or channel_id
            description = channel.get("description") or channel.get("short_description") or ""
            image = channel_image(channel)
            art = {"thumb": image, "poster": image, "icon": image} if image else None
            add_playable(title, channel_id, description, art)
            shown += 1

        if shown == 0:
            notify("Nessun canale restituito per questa sezione.")
        xbmcplugin.setContent(HANDLE, "videos")
    except ApiHttpError as exc:
        notify("Rakuten TV: errore HTTP %s nel recupero dei canali." % exc.code)
    except Exception as exc:
        xbmc.log("[MediaHub Italia] channel list error: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile recuperare i canali Rakuten TV. Consulta il log di Kodi.")
    xbmcplugin.endOfDirectory(HANDLE)


def find_channel(channel_id):
    for channel in get_channels():
        if str(channel.get("id", "")) == str(channel_id):
            return channel
    return None


def first_language_id(channel):
    labels = channel.get("labels", {}) if isinstance(channel, dict) else {}
    languages = labels.get("languages", []) if isinstance(labels, dict) else []
    for language in languages:
        if isinstance(language, dict) and language.get("id"):
            return language["id"]
    return "MIS"


def play_channel(channel_id):
    try:
        channel = find_channel(channel_id)
        if not channel:
            raise RuntimeError("Canale non trovato")

        params = rakuten_params()
        params.update({
            "device_stream_audio_quality": "2.0",
            "device_stream_hdr_type": "NONE",
            "device_stream_video_quality": "FHD",
            "disable_dash_legacy_packages": "false",
        })
        payload = {
            "audio_language": first_language_id(channel),
            "audio_quality": "2.0",
            "classification_id": CLASSIFICATION_ID,
            "content_id": channel_id,
            "content_type": "live_channels",
            "device_serial": "kodi-personal-addon",
            "player": "web:HLS-NONE:NONE",
            "strict_video_quality": False,
            "subtitle_language": "MIS",
            "video_type": "stream",
        }

        result = api_request("/avod/streamings", method="POST", params=params, payload=payload)
        infos = (result.get("data", {}) or {}).get("stream_infos", []) or []
        if not infos:
            raise RuntimeError("Rakuten non ha restituito uno stream")

        stream_url = infos[0].get("url")
        if not stream_url:
            raise RuntimeError("URL stream assente")

        # Manteniamo l'URL restituito dal servizio senza manipolare DRM o token.
        item = xbmcgui.ListItem(path=stream_url)
        item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    except Exception as exc:
        xbmc.log("[MediaHub Italia] playback error: %s" % exc, xbmc.LOGERROR)
        notify("Riproduzione non disponibile per questo canale.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def show_info():
    text = (
        "Rakuten TV - integrazione personale\n\n"
        "Questa versione usa gli endpoint del servizio per elencare e riprodurre "
        "i canali Live gratuiti disponibili per il mercato italiano.\n\n"
        "Non gestisce acquisti, noleggi, account o contenuti VOD protetti da DRM. "
        "Non rimuove né aggira protezioni.\n\n"
        "Sito ufficiale: https://www.rakuten.tv/it\n\n"
        "Se Rakuten modifica le proprie API, alcune funzioni potrebbero richiedere un aggiornamento dell'addon."
    )
    xbmcgui.Dialog().textviewer("Rakuten TV", text)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def router():
    query = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 and sys.argv[2] else {}
    mode = query.get("mode", [""])[0]

    if not mode:
        root()
    elif mode == "rakuten":
        rakuten_root()
    elif mode == "youtube":
        youtube_root()
    elif mode == "m3u":
        m3u_root()
    elif mode == "m3u_tundrak":
        m3u_tundrak_root()
    elif mode == "m3u_source":
        list_m3u(query.get("source_id", [""])[0], query.get("group", [None])[0])
    elif mode == "m3u_add":
        add_m3u_source(query.get("kind", ["url"])[0])
    elif mode == "m3u_manage":
        m3u_manage()
    elif mode == "m3u_edit":
        edit_m3u_source(query.get("source_id", [""])[0])
    elif mode == "m3u_delete":
        delete_m3u_source(query.get("source_id", [""])[0])
    elif mode == "m3u_play":
        play_m3u(
            query.get("stream_url", [""])[0],
            query.get("headers", ["{}"])[0],
            query.get("media_type", ["auto"])[0],
        )
    elif mode == "m3u_info":
        show_m3u_info()
    elif mode == "channels":
        list_channels(query.get("category", [None])[0])
    elif mode == "play":
        play_channel(query.get("channel_id", [""])[0])
    elif mode == "info":
        show_info()
    else:
        root()


if __name__ == "__main__":
    router()
