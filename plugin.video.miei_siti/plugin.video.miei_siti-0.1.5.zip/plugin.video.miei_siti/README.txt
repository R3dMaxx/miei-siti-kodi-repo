MEDIAHUB ITALIA - versione 0.1.5

Installazione in Kodi:
1. Impostazioni > Sistema > Add-on > abilita "Sorgenti sconosciute" se necessario.
2. Add-on > Installa da un file zip.
3. Seleziona plugin.video.miei_siti-0.1.5.zip.
4. Apri Add-on video > MediaHub Italia.

Funzioni attuali:
- Elenco dei canali Rakuten TV Live gratuiti disponibili per l'Italia.
- Categorie, quando restituite dall'API.
- Riproduzione tramite URL HLS fornito dal servizio al momento della selezione.
- Sezione YouTube con Film&More, Movies in Action, FilmRari, Moviedome IT e CineMadame.
- Elenco degli upload pubblici e playback YouTube delegati a plugin.video.youtube.
- Liste M3U online o locali per TV in chiaro, radio e VOD.
- TV Italia tramite la raccolta Forgejo peppenamir/iptv_italia.
- TV Italia - Tundrak con le varianti Essenziale e Completa.
- Radio Italia tramite la raccolta Tundrak/IPTV-Italia.
- Gestione delle liste personali direttamente da Kodi: aggiunta, modifica ed eliminazione.
- Supporto per gruppi, loghi, numerazione e header HTTP definiti nella playlist.

Limiti:
- Nessun accesso a noleggio/acquisto/Videoteca.
- Nessun aggiramento DRM o autenticazione.
- L'API Rakuten TV non e' documentata pubblicamente e puo' cambiare.
- Cataloghi e playback possono dipendere dalla posizione geografica.
- YouTube richiede l'addon plugin.video.youtube installato; l'elenco degli upload
  pubblici non richiede una API key personale.
- Le liste predefinite sono lette dai progetti peppenamir/iptv_italia e
  Tundrak/IPTV-Italia e non sono incluse nel pacchetto. Disponibilita' e
  funzionamento dipendono dalle sorgenti.
- Non sono supportati portali Xtream, credenziali o contenuti protetti da DRM.

Compatibilita': Kodi con Python 3 (Kodi 19+).

Novita 0.1.5:
- Aggiunta TV Italia basata sulla lista Forgejo.
- Aggiunto il sottomenu TV Italia - Tundrak con le versioni Essenziale e Completa.
- Rinominato il collegamento radio in Radio Italia.
- Restano disponibili liste personali tramite URL web/cloud diretto o file locale.

Novita 0.1.4:
- Nuovo nome visibile MediaHub Italia; l'ID tecnico resta invariato per gli aggiornamenti.
- Nuova icona ad alta leggibilita' per TV.
- Rimossa completamente l'integrazione Pluto TV.
- Aggiunte liste M3U online/locali, preset IPTV-Italia e gestione sorgenti personali.
- Mantenute le integrazioni Rakuten TV e YouTube gia' funzionanti.

Novita 0.1.3:
- I canali YouTube aprono direttamente la playlist pubblica degli upload senza API key.
- Mantenuta invariata l'integrazione Rakuten TV della versione 0.1.1.

Novita 0.1.2:
- Aggiunti cinque canali pubblici nella sezione YouTube.
- Mantenuta invariata l'integrazione Rakuten TV della versione 0.1.1.

Novita 0.1.1:
- Rimossa la richiesta fissa per_page=100, ora rifiutata dall API Rakuten.
- Aggiunta paginazione robusta con fallback sui page size accettati.
- Migliorati logging e messaggi di errore HTTP.
