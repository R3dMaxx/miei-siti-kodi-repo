# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import sys
import urllib.parse
import urllib.request
import urllib.error
import uuid
from datetime import datetime, timedelta, timezone

import guide
import tmdb

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

API_BASE = "https://gizmo.rakuten.tv/v3"
MARKET = "it"
LOCALE = "it"
CLASSIFICATION_ID = 36

HEADERS = {
    "Origin": "https://www.rakuten.tv",
    "Referer": "https://www.rakuten.tv/it",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0 Safari/537.36"
    ),
    "Accept": "application/json",
}

ADDON_NAME = "MediaHub Italia"
ADDON_ID = "plugin.video.miei_siti"
DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID)
SOURCES_FILE = DATA_DIR.rstrip("/\\") + "/sources.json"
GUIDE_CONFIG_FILE = DATA_DIR.rstrip("/\\") + "/guide_source.json"
GUIDE_CACHE_FILE = DATA_DIR.rstrip("/\\") + "/guide_cache.json"
FOLLOWED_FILE = DATA_DIR.rstrip("/\\") + "/followed.json"
TMDB_CONFIG_FILE = DATA_DIR.rstrip("/\\") + "/tmdb_config.json"
ARTWORK_FILE = DATA_DIR.rstrip("/\\") + "/artwork_seen.json"
ARTWORK_SEEN = set()
MAX_TRACKED_ART = 3000
DEFAULT_GUIDE_URL = "https://epgshare01.online/epgshare01/epg_ripper_IT1.xml.gz"
BACKUP_GUIDE_URL = "https://www.open-epg.com/files/italy3.xml.gz"
OLD_RECOMMENDED_GUIDE_URL = "https://tvit.leicaflorianrobert.dev/epg/list.xml"
MAX_PLAYLIST_BYTES = 5 * 1024 * 1024
MAX_PLAYLIST_ITEMS = 5000

M3U_PRESETS = {
    "tv_italia": {
        "id": "tv_italia",
        "name": "TV Italia",
        "location": "https://forgejo.it/peppenamir/iptv_italia/raw/branch/main/lista.m3u",
        "kind": "url",
        "media_type": "tv",
        "preset": True,
    },
    # Conservata per i preferiti creati con le versioni precedenti; non appare nel menu.
    "tundrak_basic": {
        "id": "tundrak_basic",
        "name": "TV Italia - Base",
        "location": "https://github.com/Tundrak/IPTV-Italia/raw/main/iptvita.m3u",
        "kind": "url",
        "media_type": "tv",
        "preset": True,
    },
    "tundrak_plus": {
        "id": "tundrak_plus",
        "name": "TV Italia - Completa",
        "location": "https://github.com/Tundrak/IPTV-Italia/raw/main/iptvitaplus.m3u",
        "kind": "url",
        "media_type": "tv",
        "preset": True,
    },
    "iptvita_radio": {
        "id": "iptvita_radio",
        "name": "IPTV Italia - Radio",
        "location": "https://github.com/Tundrak/IPTV-Italia/raw/main/ipradioita.m3u",
        "kind": "url",
        "media_type": "radio",
        "preset": True,
    },
}

YOUTUBE_CHANNELS = (
    ("Film&More", "UC2DWplnIpAtu9OWgH9-ZVrQ"),
    ("Movies in Action", "UCyzV93S6FKWPNtbxvl2DmJQ"),
    ("FilmRari", "UCzLtrdBKjZIBcs8aWR06Yuw"),
    ("Moviedome IT", "UC4rMaEpZKmKwQJHtMUi3IaA"),
    ("CineMadame", "UCG6uomZkstGuNLwGmYMLbJw"),
    ("Italy on a click", "UCkCvLSWRn0yHrnYy4eAb7zQ"),
)


def notify(message, title=ADDON_NAME):
    xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, 5000)


class ApiHttpError(RuntimeError):
    def __init__(self, code, body=""):
        self.code = code
        self.body = body or ""
        super().__init__("HTTP %s: %s" % (code, self.body[:300]))


def api_request(path, method="GET", params=None, payload=None):
    params = params or {}
    query = urllib.parse.urlencode(params)
    url = API_BASE + path + ("?" + query if query else "")
    headers = dict(HEADERS)
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        xbmc.log("[MediaHub Italia] HTTP %s: %s" % (exc.code, body), xbmc.LOGERROR)
        raise ApiHttpError(exc.code, body) from exc
    except Exception as exc:
        xbmc.log("[MediaHub Italia] API error: %s" % exc, xbmc.LOGERROR)
        raise


def rakuten_params():
    return {
        "classification_id": CLASSIFICATION_ID,
        "device_identifier": "web",
        "locale": LOCALE,
        "market_code": MARKET,
    }


def _channel_page(page, per_page=None):
    params = rakuten_params()
    params["page"] = page
    if per_page is not None:
        params["per_page"] = per_page
    return api_request("/live_channels", params=params)


def _first_channel_page():
    # Rakuten ha iniziato a rifiutare per_page=100 con HTTP 400.
    # Preferiamo quindi il page size predefinito del servizio; se in futuro
    # diventasse obbligatorio, proviamo alcuni valori conservativi.
    try:
        return _channel_page(1, None), None
    except ApiHttpError as exc:
        if exc.code != 400:
            raise
        first_error = exc

    for candidate in (50, 25, 20, 10):
        try:
            result = _channel_page(1, candidate)
            xbmc.log(
                "[MediaHub Italia] Rakuten per_page accettato: %s" % candidate,
                xbmc.LOGINFO,
            )
            return result, candidate
        except ApiHttpError as exc:
            if exc.code == 400 and "invalid_per_page" in exc.body:
                continue
            raise

    raise first_error


def _pagination_last_page(result):
    # L'API non e' documentata: supportiamo i nomi piu' comuni senza
    # dipendere da una struttura specifica.
    candidates = []
    for key in ("meta", "pagination"):
        value = result.get(key)
        if isinstance(value, dict):
            candidates.append(value)
            nested = value.get("pagination")
            if isinstance(nested, dict):
                candidates.append(nested)

    for data in candidates:
        for key in ("total_pages", "last_page", "pages"):
            value = data.get(key)
            try:
                value = int(value)
            except (TypeError, ValueError):
                continue
            if value > 0:
                return value
    return None


def get_channels():
    first_result, per_page = _first_channel_page()
    channels = []
    seen_ids = set()
    page = 1
    result = first_result
    max_pages = 100

    while page <= max_pages:
        page_channels = result.get("data", []) or []
        if not isinstance(page_channels, list):
            raise RuntimeError("Formato inatteso nella risposta live_channels")
        if not page_channels:
            break

        new_items = 0
        for channel in page_channels:
            if not isinstance(channel, dict):
                continue
            channel_id = str(channel.get("id", ""))
            if channel_id and channel_id in seen_ids:
                continue
            if channel_id:
                seen_ids.add(channel_id)
            channels.append(channel)
            new_items += 1

        xbmc.log(
            "[MediaHub Italia] Rakuten live page %s: %s elementi (%s nuovi)"
            % (page, len(page_channels), new_items),
            xbmc.LOGINFO,
        )

        # Se la pagina e' interamente duplicata, evitiamo un loop nel caso
        # in cui Rakuten ignori il parametro page.
        if new_items == 0:
            break

        last_page = _pagination_last_page(result)
        if last_page is not None and page >= last_page:
            break

        page += 1
        result = _channel_page(page, per_page)

    if page > max_pages:
        xbmc.log(
            "[MediaHub Italia] Interrotta paginazione Rakuten al limite di %s pagine"
            % max_pages,
            xbmc.LOGWARNING,
        )

    return channels


def get_categories():
    result = api_request("/live_channel_categories", params=rakuten_params())
    return result.get("data", []) or []


def build_url(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def menu_art(icon):
    return os.path.join(os.path.dirname(__file__), "resources", "icons", icon + ".png") if icon else "DefaultFolder.png"


def set_media_art(item, art):
    item.setArt(art)
    for value in art.values():
        if isinstance(value, str) and (value.startswith(("http://", "https://"))
                                       or value.startswith(os.path.dirname(__file__) + os.sep)):
            ARTWORK_SEEN.add(value)


def save_artwork_seen():
    if not ARTWORK_SEEN:
        return
    try:
        previous = _read_json_file(ARTWORK_FILE, [])
        if not isinstance(previous, list):
            previous = []
        urls = list(dict.fromkeys([url for url in previous if isinstance(url, str)] + sorted(ARTWORK_SEEN)))
        _write_json_file(ARTWORK_FILE, urls[-MAX_TRACKED_ART:])
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Registro immagini: %s" % exc, xbmc.LOGWARNING)


def add_folder(label, *, icon=None, plot="", **kwargs):
    item = xbmcgui.ListItem(label=label)
    art = menu_art(icon)
    set_media_art(item, {"icon": art, "thumb": art})
    if plot:
        item.setInfo("video", {"title": label, "plot": plot})
        item.addContextMenuItems([("Cosa fa questa voce?", "RunPlugin(%s)" %
                                  build_url(mode="menu_info", title=label, description=plot))])
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**kwargs), item, True)


def add_external_folder(label, url, *, icon=None, plot=""):
    item = xbmcgui.ListItem(label=label)
    art = menu_art(icon)
    set_media_art(item, {"icon": art, "thumb": art})
    if plot:
        item.setInfo("video", {"title": label, "plot": plot})
        item.addContextMenuItems([("Cosa fa questa voce?", "RunPlugin(%s)" %
                                  build_url(mode="menu_info", title=label, description=plot))])
    xbmcplugin.addDirectoryItem(HANDLE, url, item, True)


def show_menu_info(title, description):
    xbmcgui.Dialog().textviewer(title, description)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _ensure_data_dir():
    if not xbmcvfs.exists(DATA_DIR):
        xbmcvfs.mkdirs(DATA_DIR)


def load_custom_sources():
    if not xbmcvfs.exists(SOURCES_FILE):
        return []
    try:
        handle = xbmcvfs.File(SOURCES_FILE)
        raw = handle.read()
        handle.close()
        data = json.loads(raw or "[]")
        return [source for source in data if isinstance(source, dict)] if isinstance(data, list) else []
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Lettura sorgenti M3U fallita: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile leggere le sorgenti M3U salvate.")
        return []


def save_custom_sources(sources):
    _ensure_data_dir()
    handle = xbmcvfs.File(SOURCES_FILE, "w")
    handle.write(json.dumps(sources, ensure_ascii=False, indent=2))
    handle.close()


def _read_json_file(path, fallback):
    if not xbmcvfs.exists(path):
        return fallback
    try:
        handle = xbmcvfs.File(path)
        value = json.loads(handle.read())
        handle.close()
        return value
    except Exception:
        return fallback


def _write_json_file(path, value):
    _ensure_data_dir()
    handle = xbmcvfs.File(path, "w")
    handle.write(json.dumps(value, ensure_ascii=False))
    handle.close()


def _texture_url(value):
    if value.startswith("image://"):
        value = urllib.parse.unquote(value[len("image://"):])
    return value.rstrip("/")


def _kodi_jsonrpc(method, params):
    payload = json.dumps({"jsonrpc": "2.0", "id": "mediahub-clean", "method": method,
                          "params": params}, ensure_ascii=False)
    reply = json.loads(xbmc.executeJSONRPC(payload))
    if "error" in reply:
        raise RuntimeError("Kodi: %s" % reply["error"].get("message", "errore JSON-RPC"))
    return reply.get("result", {})


def clean_mediahub_textures(urls):
    # Kodi gestisce insieme le miniature di tutti gli add-on: si rimuovono solo URL
    # registrati quando MediaHub ha mostrato l'immagine, mai l'intera cartella Thumbnails.
    allowed = {_texture_url(url) for url in urls if isinstance(url, str) and url}
    if not allowed:
        return 0
    hosts = {urllib.parse.urlparse(url).hostname for url in allowed if url.startswith(("http://", "https://"))}
    needles = sorted(host for host in hosts if host)
    if any(url.startswith(os.path.dirname(__file__) + os.sep) for url in allowed):
        needles.append(ADDON_ID)
    removed = 0
    seen_ids = set()
    for offset in range(0, len(needles), 20):
        filters = [{"field": "url", "operator": "contains", "value": value}
                   for value in needles[offset:offset + 20]]
        query_filter = filters[0] if len(filters) == 1 else {"or": filters}
        result = _kodi_jsonrpc("Textures.GetTextures", {"properties": ["url"], "filter": query_filter})
        for texture in result.get("textures") or []:
            texture_id = texture.get("textureid")
            if (texture_id in seen_ids or not isinstance(texture_id, int)
                    or _texture_url(texture.get("url") or "") not in allowed):
                continue
            _kodi_jsonrpc("Textures.RemoveTexture", {"textureid": texture_id})
            seen_ids.add(texture_id)
            removed += 1
    return removed


def clean_cache():
    try:
        registered = _read_json_file(ARTWORK_FILE, [])
        registered = registered if isinstance(registered, list) else []
        has_guide = xbmcvfs.exists(GUIDE_CACHE_FILE)
        directories, files = xbmcvfs.listdir(DATA_DIR) if xbmcvfs.exists(DATA_DIR) else ([], [])
        # Il prefisso limita l'operazione a file temporanei propri, senza toccare
        # sources.json, followed.json, guide_source.json o tmdb_config.json.
        temporary = [name for name in files if re.fullmatch(r"mediahub_[\w.-]+\.(?:tmp|part|cache)", name)]
        if not xbmcgui.Dialog().yesno(ADDON_NAME, "Pulire la cache della guida TV, %s immagini "
                                      "registrate e %s file temporanei?\n\n"
                                      "Codice TMDb, liste e titoli seguiti resteranno salvati." %
                                      (len(registered), len(temporary))):
            return
        images = 0
        images_error = ""
        try:
            images = clean_mediahub_textures(registered)
        except Exception as exc:
            images_error = str(exc)
            xbmc.log("[MediaHub Italia] Pulizia immagini: %s" % exc, xbmc.LOGWARNING)
        if not images_error and xbmcvfs.exists(ARTWORK_FILE):
            xbmcvfs.delete(ARTWORK_FILE)
        guide_removed = bool(has_guide and xbmcvfs.delete(GUIDE_CACHE_FILE))
        temp_removed = sum(1 for name in temporary if xbmcvfs.delete(DATA_DIR.rstrip("/\\") + "/" + name))
        message = "Guida TV: %s.\nImmagini: %s.\nFile temporanei: %s." % (
            "pulita" if guide_removed else "nessuna cache da pulire", images, temp_removed)
        if images_error:
            message += "\n\nKodi non ha consentito di pulire le immagini. Riprova più tardi."
        xbmcgui.Dialog().ok("Pulizia e spazio", message)
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Pulizia: %s" % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Pulizia e spazio", "Non è stato possibile completare la pulizia. "
                            "Le impostazioni sono conservate.")
    finally:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def guide_source():
    value = _read_json_file(GUIDE_CONFIG_FILE, {})
    custom = value.get("url", "") if isinstance(value, dict) else ""
    # The source suggested for 0.1.6 can be stale or unreachable. Upgrade it
    # transparently to the built-in Italian guide; preserve other custom URLs.
    return custom if custom and custom != OLD_RECOMMENDED_GUIDE_URL else DEFAULT_GUIDE_URL


def configure_guide():
    current = guide_source()
    value = xbmcgui.Dialog().input(
        "URL della guida TV XMLTV (.xml o .xml.gz)",
        defaultt=current or "https://", type=xbmcgui.INPUT_ALPHANUM,
    ).strip()
    if value in ("", "https://"):
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % build_url(mode="guide_settings"))
        return
    if urllib.parse.urlparse(value).scheme not in ("http", "https"):
        notify("Inserisci un indirizzo HTTP o HTTPS valido.")
    else:
        _write_json_file(GUIDE_CONFIG_FILE, {"url": value})
        _write_json_file(GUIDE_CACHE_FILE, {})
        notify("Guida TV salvata. Apri 'Stasera in TV'.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    xbmc.executebuiltin("Container.Update(%s,replace)" % build_url(mode="guide_settings"))


def restore_default_guide():
    _write_json_file(GUIDE_CONFIG_FILE, {})
    _write_json_file(GUIDE_CACHE_FILE, {})
    notify("Guida italiana predefinita ripristinata.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    xbmc.executebuiltin("Container.Update(%s,replace)" % build_url(mode="guide_settings"))


def schedule_programmes():
    source = guide_source()
    if not source:
        return []
    cached = _read_json_file(GUIDE_CACHE_FILE, {})
    now = datetime.now(guide.ROME)
    evening = guide.evening_bounds(now)[0].date().isoformat()
    if (isinstance(cached, dict) and cached.get("schema") == 3 and cached.get("url") == source
            and cached.get("evening") == evening
            and cached.get("fetched", 0) > datetime.now(timezone.utc).timestamp() - 6 * 3600):
        return cached.get("items", [])
    try:
        items = guide.parse_window(
            guide.download_xmltv(source), guide.evening_bounds(now)[0],
            now + timedelta(days=8),
        )
        if not items:
            raise ValueError("La guida non contiene programmi per questa sera")
    except Exception as exc:
        if source != DEFAULT_GUIDE_URL:
            raise
        xbmc.log("[MediaHub Italia] Guida principale non disponibile: %s" % exc, xbmc.LOGWARNING)
        items = guide.parse_window(
            guide.download_xmltv(BACKUP_GUIDE_URL), guide.evening_bounds(now)[0],
            now + timedelta(days=8),
        )
    # The primary guide can contain thousands of non-fiction programmes.
    items = [item for item in items if item["kind"]]
    _write_json_file(GUIDE_CACHE_FILE, {
        "schema": 3, "url": source, "evening": evening,
        "fetched": datetime.now(timezone.utc).timestamp(), "items": items,
    })
    return items


def evening_programmes():
    start, end = guide.evening_bounds()
    return [item for item in schedule_programmes()
            if datetime.fromisoformat(item["start"]) < end
            and (datetime.fromisoformat(item["stop"]) if item["stop"] else datetime.fromisoformat(item["start"]) + timedelta(hours=2)) > start]


def follow_key(kind, title, year=""):
    title = " ".join(title.casefold().split())
    return "%s|%s|%s" % (kind, title, year if kind == "Film" else "")


def load_followed():
    value = _read_json_file(FOLLOWED_FILE, [])
    return [item for item in value if isinstance(item, dict)
            and item.get("kind") in ("Film", "Serie TV") and item.get("title")] if isinstance(value, list) else []


def is_followed(programme, tracked):
    if programme["kind"] != tracked["kind"] or " ".join(programme["title"].casefold().split()) != " ".join(tracked["title"].casefold().split()):
        return False
    return (programme["kind"] == "Serie TV" or not tracked.get("year")
            or not programme.get("year") or programme["year"] == tracked["year"])


def toggle_follow(kind, title, year=""):
    if kind not in ("Film", "Serie TV") or not title.strip():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    tracked = load_followed()
    key = follow_key(kind, title, year)
    existing = next((index for index, item in enumerate(tracked)
                     if follow_key(item["kind"], item["title"], item.get("year", "")) == key), None)
    if existing is None:
        tracked.append({"kind": kind, "title": title, "year": year if kind == "Film" else ""})
        notify("Aggiunto ai titoli seguiti: %s" % title)
    else:
        del tracked[existing]
        notify("Rimosso dai titoli seguiti: %s" % title)
    _write_json_file(FOLLOWED_FILE, tracked)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def add_follow_context(item, programme, tracked):
    already = any(is_followed(programme, entry) for entry in tracked)
    label = "Smetti di seguire" if already else "Segui questo titolo"
    target = build_url(mode="follow_toggle", kind=programme["kind"],
                       title=programme["title"], year=programme.get("year", ""))
    item.addContextMenuItems([(label, "RunPlugin(%s)" % target)])


def list_followed():
    xbmcplugin.setPluginCategory(HANDLE, "Seguiti")
    tracked = load_followed()
    if not tracked:
        notify("Tieni premuto OK su un film o una serie, poi scegli 'Segui questo titolo'.")
    try:
        schedule = schedule_programmes() if tracked else []
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Seguiti: %s" % exc, xbmc.LOGERROR)
        notify("Passaggi TV non disponibili; i titoli seguiti restano salvati.")
        schedule = []
    now = datetime.now(guide.ROME)
    for entry in tracked:
        matches = [p for p in schedule if is_followed(p, entry)
                   and datetime.fromisoformat(p["stop"] or p["start"]) > now]
        label = entry["title"]
        if entry.get("year"):
            label += " (%s)" % entry["year"]
        if matches:
            label += " · %s" % datetime.fromisoformat(matches[0]["start"]).strftime("%d/%m %H:%M")
        else:
            label += " · nessun passaggio noto"
        item = xbmcgui.ListItem(label=label)
        set_media_art(item, {"icon": "DefaultVideo.png"})
        key = follow_key(entry["kind"], entry["title"], entry.get("year", ""))
        remove = build_url(mode="follow_toggle", kind=entry["kind"], title=entry["title"], year=entry.get("year", ""))
        item.addContextMenuItems([("Smetti di seguire", "RunPlugin(%s)" % remove)])
        xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="followed_title", key=key), item, True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def followed_airings():
    xbmcplugin.setPluginCategory(HANDLE, "Prossimi passaggi dei titoli seguiti")
    tracked = load_followed()
    try:
        now = datetime.now(guide.ROME)
        if not tracked:
            notify("Non hai ancora titoli seguiti. Aggiungili dal menu contestuale di una scheda.")
        else:
            shown = 0
            for index, programme in enumerate(schedule_programmes()):
                if not any(is_followed(programme, entry) for entry in tracked):
                    continue
                start = datetime.fromisoformat(programme["start"])
                if start <= now:
                    continue
                label = "%s · %s · %s" % (start.strftime("%d/%m %H:%M"),
                                          programme["channel"], programme["title"])
                item = xbmcgui.ListItem(label=label)
                art = programme.get("image")
                set_media_art(item, {"icon": art, "thumb": art} if art else {"icon": "DefaultVideo.png"})
                item.setInfo("video", {"title": programme["title"], "plot": programme["description"]})
                xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="guide_detail", scope="schedule", index=index), item, True)
                shown += 1
            if not shown:
                notify("Nessun futuro passaggio noto nella guida TV per i titoli seguiti.")
        xbmcplugin.setContent(HANDLE, "videos")
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Passaggi seguiti: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile leggere i passaggi dalla guida TV.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def followed_title(key):
    tracked = next((p for p in load_followed()
                    if follow_key(p["kind"], p["title"], p.get("year", "")) == key), None)
    if not tracked:
        notify("Titolo seguito non trovato.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, tracked["title"])
    try:
        now = datetime.now(guide.ROME)
        shown = 0
        for index, programme in enumerate(schedule_programmes()):
            if not is_followed(programme, tracked) or datetime.fromisoformat(programme["stop"] or programme["start"]) <= now:
                continue
            start = datetime.fromisoformat(programme["start"]).strftime("%d/%m %H:%M")
            label = "%s · %s" % (start, programme["channel"])
            if programme.get("episode"):
                label += " · %s" % ("S%s E%s" % (programme["season"], programme["episode"]) if programme.get("season") else "E%s" % programme["episode"])
            item = xbmcgui.ListItem(label=label)
            set_media_art(item, {"icon": "DefaultVideo.png"})
            xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="guide_detail", scope="schedule", index=index), item, True)
            shown += 1
        if not shown:
            notify("Nessun prossimo passaggio nella guida disponibile.")
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Passaggi seguiti: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile consultare la guida TV.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def discover_root():
    # Percorso mantenuto per eventuali collegamenti Kodi creati nelle versioni precedenti.
    root()


def upcoming_root():
    xbmcplugin.setPluginCategory(HANDLE, "In arrivo")
    add_folder("Film in arrivo – TMDb", mode="tmdb_cinema", icon="cinema",
               plot="Uscite nei cinema italiani nei prossimi 60 giorni, secondo TMDb. "
                    "Non indica la data di arrivo sulle piattaforme streaming. La stella indica i titoli seguiti.")
    add_folder("Serie TV in arrivo – TMDb", mode="tmdb_series", icon="series",
               plot="Nuove serie nei prossimi 60 giorni e prossimi episodi delle serie seguite, quando TMDb ne indica la data. "
                    "Le date possono riferirsi alla prima trasmissione estera: non confermano l'uscita italiana.")
    add_folder("Film in arrivo dal sito JustWatch", mode="public_site", source="films", icon="film",
               plot="Apre nel browser le future uscite dei film sulle piattaforme italiane elencate da JustWatch.")
    add_folder("Serie in arrivo dal sito JustWatch", mode="public_site", source="series", icon="series",
               plot="Apre nel browser le future uscite delle serie sulle piattaforme italiane elencate da JustWatch.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


PUBLIC_SITES = {
    "series": ("Serie TV in arrivo in Italia", "https://www.justwatch.com/it/serie-tv/prossimamente"),
    "films": ("Film in arrivo in streaming in Italia", "https://www.justwatch.com/it/film/prossimamente"),
}


def open_public_site(source):
    name, url = PUBLIC_SITES.get(source, (None, None))
    if not url:
        notify("Sito esterno non riconosciuto.")
    elif xbmc.getCondVisibility("System.Platform.Android"):
        xbmc.executebuiltin("StartAndroidActivity(,android.intent.action.VIEW,,%s)" % url)
    else:
        xbmcgui.Dialog().textviewer(name, "Apri nel browser:\n\n" + url)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def evening_root():
    xbmcplugin.setPluginCategory(HANDLE, "Stasera in TV")
    add_folder("Film stasera", mode="guide_films", icon="film",
               plot="Mostra i film previsti stasera dalla guida TV italiana, con orario, canale e scheda.")
    add_folder("Serie TV stasera", mode="guide_series", icon="series",
               plot="Mostra le serie previste stasera; stagione ed episodio compaiono quando la guida li fornisce.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def followed_root():
    xbmcplugin.setPluginCategory(HANDLE, "Titoli seguiti")
    add_folder("I miei film e le mie serie", mode="followed", icon="star",
               plot="Elenco dei titoli che segui. Tieni premuto OK su una scheda e scegli 'Segui questo titolo' "
                    "per aggiungerne altri.")
    add_folder("Prossimi passaggi in TV", mode="followed_airings", icon="guide",
               plot="Riunisce i prossimi passaggi in TV dei titoli seguiti presenti nella guida configurata.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def watch_root():
    xbmcplugin.setPluginCategory(HANDLE, "Canali e liste")
    add_folder("Rakuten TV · canali Live gratuiti", mode="rakuten", icon="play",
               plot="Apre i canali Live gratuiti disponibili tramite Rakuten TV.")
    add_folder("YouTube · canali selezionati", mode="youtube", icon="youtube",
               plot="Apre gli ultimi video pubblicati dai canali selezionati tramite l'add-on YouTube per Kodi.")
    add_folder("TV e radio Italia", mode="tv_radio", icon="tv",
               plot="Apre le liste pubbliche preimpostate di canali TV e radio; disponibilità e qualità dipendono dalle fonti.")
    add_folder("Le mie liste M3U", mode="m3u", icon="list",
               plot="Apre le liste personali che hai aggiunto e le opzioni per aggiungerle o modificarle.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tv_radio_root():
    xbmcplugin.setPluginCategory(HANDLE, "TV e radio Italia")
    add_folder("TV Italia – Peppenamir", mode="m3u_source", source_id="tv_italia", icon="tv",
               plot="Carica i canali italiani in chiaro della lista pubblica Peppenamir.")
    add_folder("TV Italia – Tundrak", mode="m3u_source", source_id="tundrak_plus", icon="tv",
               plot="Apre direttamente la lista Tundrak completa, con loghi e categorie.")
    add_folder("Radio Italia", mode="m3u_source", source_id="iptvita_radio", icon="radio",
               plot="Carica le emittenti della lista radio preimpostata.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def settings_root():
    xbmcplugin.setPluginCategory(HANDLE, "Impostazioni e fonti")
    add_folder("Cambia il codice TMDb" if tmdb_token() else "Inserisci il codice TMDb",
               mode="tmdb_config", icon="key",
               plot="Inserisce o sostituisce il codice personale; il nuovo codice viene verificato "
                    "con TMDb prima di essere salvato.")
    add_folder("Come ottenere il codice TMDb", mode="tmdb_help", icon="info",
               plot="Spiega dove trovare la chiave API breve o il codice di lettura lungo nel proprio account TMDb.")
    add_folder("Guida TV · fonte e impostazioni", mode="guide_settings", icon="guide",
               plot="Consulta la fonte della guida TV, imposta un file XMLTV personale o ripristina la guida predefinita.")
    add_folder("Che cos'è MediaHub Italia", mode="about", icon="info",
               plot="Spiega quali dati consulta e quali contenuti possono essere riprodotti dall'add-on.")
    add_folder("Crediti e limiti delle fonti", mode="tmdb_credits", icon="info",
               plot="Leggi attribuzioni di TMDb e JustWatch e i limiti delle date e delle disponibilità indicate.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def guide_settings_root():
    xbmcplugin.setPluginCategory(HANDLE, "Guida TV · fonte e impostazioni")
    source = guide_source()
    current = "Guida italiana predefinita" if source == DEFAULT_GUIDE_URL else "Guida personale"
    add_folder("Fonte attiva: " + current, mode="guide_source_info", icon="info",
               plot="Mostra l'indirizzo della guida XMLTV attualmente utilizzata per 'Stasera in TV'.")
    add_folder("Imposta una guida TV personale", mode="guide_config", icon="guide",
               plot="Inserisci l'indirizzo diretto di una guida italiana in formato XML o XML.GZ.")
    add_folder("Ripristina la guida italiana predefinita", mode="guide_default", icon="settings",
               plot="Rimuove l'indirizzo della guida personale e torna alla fonte preimpostata.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def guide_source_info():
    xbmcgui.Dialog().textviewer("Fonte della guida TV", "Fonte attiva:\n%s\n\n"
                                "Le categorie Film e Serie TV dipendono dai dati presenti nel file XMLTV." % guide_source())
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def mediahub_about():
    xbmcgui.Dialog().textviewer("Che cos'è MediaHub Italia", (
        "MediaHub Italia aiuta a scegliere cosa guardare e riunisce fonti video in Kodi.\n\n"
        "CERCA: schede di film e serie da TMDb, con le disponibilità italiane riportate "
        "tramite JustWatch. Non serve accedere a Netflix o Prime Video nell'add-on.\n\n"
        "IN ARRIVO: cinema italiano e nuove serie nei prossimi 60 giorni sono elencati "
        "dentro Kodi con TMDb; compaiono anche i prossimi episodi delle serie seguite "
        "quando disponibili. Le date TV non confermano l'uscita italiana. "
        "Le future uscite streaming italiane si consultano nel browser su JustWatch: "
        "quelle pagine non sono importate né evidenziano i titoli seguiti.\n\n"
        "STASERA E SEGUITI: la guida TV XMLTV mostra film e serie della serata "
        "e i prossimi passaggi dei titoli seguiti, se presenti nella fonte.\n\n"
        "CANALI E LISTE: Rakuten TV Live, canali YouTube pubblici, TV e radio "
        "da liste M3U preimpostate o personali. La riproduzione dipende dalla fonte "
        "e dagli add-on necessari.\n\n"
        "PULIZIA E SPAZIO: cancella i dati temporanei e le immagini registrate "
        "dall'add-on senza rimuovere liste, titoli seguiti o codice TMDb.\n\n"
        "Le date e i cataloghi possono cambiare. L'add-on non apre i cataloghi "
        "in abbonamento e non aggira protezioni o accessi."
    ))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tmdb_token():
    value = _read_json_file(TMDB_CONFIG_FILE, {})
    return value.get("token", "").strip() if isinstance(value, dict) else ""


def configure_tmdb():
    dialog = xbmcgui.Dialog()
    token = dialog.input("Codice personale TMDb (non la password)", defaultt="",
                         type=xbmcgui.INPUT_ALPHANUM,
                         option=getattr(xbmcgui, "ALPHANUM_HIDE_INPUT", 0)).strip()
    if token:
        try:
            tmdb.request(token, "/configuration")
        except tmdb.TMDBError as exc:
            dialog.ok("Codice TMDb non salvato", str(exc))
        else:
            _write_json_file(TMDB_CONFIG_FILE, {"token": token})
            dialog.ok("TMDb attivato", "Codice verificato e salvato. Ora puoi cercare film e serie TV.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    xbmc.executebuiltin("Container.Update(%s,replace)" % build_url(mode="settings"))


def verify_tmdb():
    token = tmdb_token()
    if not token:
        xbmcgui.Dialog().ok("TMDb", "Nessun codice salvato. Apri 'Inserisci il codice TMDb'.")
    else:
        try:
            tmdb.request(token, "/configuration")
        except tmdb.TMDBError as exc:
            xbmcgui.Dialog().ok("Verifica TMDb non riuscita", str(exc))
        else:
            xbmcgui.Dialog().ok("TMDb", "Codice valido e connessione funzionante.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    xbmc.executebuiltin("Container.Update(%s,replace)" % build_url(mode="settings"))


def tmdb_help():
    xbmcgui.Dialog().textviewer("Come attivare TMDb", (
        "Per cercare film e serie e vedere le piattaforme italiane serve un "
        "codice personale TMDb. L'iscrizione al sito e l'uso personale non "
        "commerciale sono gratuiti.\n\n"
        "1. Da un computer apri https://www.themoviedb.org e crea un account "
        "gratuito, oppure accedi se ne hai gia' uno.\n"
        "2. Nel sito apri le impostazioni del tuo account e seleziona la voce "
        "'API' (e' il nome della sezione usato dal sito). Richiedi l'accesso "
        "per uso personale/non commerciale e compila gli eventuali campi richiesti.\n"
        "3. Copia la chiave API breve oppure il codice lungo indicato come "
        "'API Read Access Token' nella pagina del tuo account.\n"
        "4. In MediaHub Italia apri Impostazioni e fonti > Inserisci il codice TMDb, "
        "incolla il codice e conferma.\n\n"
        "Nell'addon non inserire email, nome utente o password di TMDb, "
        "Netflix, Prime Video o altri servizi. Il codice resta nei dati locali "
        "del profilo Kodi. Non inviarlo in chat."
    ))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def require_tmdb():
    token = tmdb_token()
    if not token:
        notify("Apri Impostazioni e fonti > Inserisci il codice TMDb.")
    return token


def tmdb_error(exc):
    xbmc.log("[MediaHub Italia] TMDb: %s" % exc, xbmc.LOGWARNING)
    notify(str(exc) if isinstance(exc, tmdb.TMDBError) else "Impossibile leggere i dati TMDb.")


def tmdb_media_item(data, kind, prefix=""):
    media_id = data.get("id")
    if not media_id:
        return
    name = tmdb.title(data, kind)
    year = tmdb.year(data, kind)
    label = "%s%s%s" % (prefix, name, " (%s)" % year if year else "")
    programme = {"kind": "Film" if kind == "movie" else "Serie TV", "title": name, "year": year}
    if any(is_followed(programme, entry) for entry in load_followed()):
        label = "★ " + label
    item = xbmcgui.ListItem(label=label)
    artwork = tmdb.poster(data.get("poster_path"))
    if artwork:
        set_media_art(item, {"poster": artwork, "thumb": artwork, "icon": artwork})
    else:
        set_media_art(item, {"icon": "DefaultVideo.png"})
    item.setInfo("video", {"title": name, "year": int(year) if year.isdigit() else 0,
                           "plot": data.get("overview") or "Descrizione non disponibile."})
    add_follow_context(item, programme, load_followed())
    xbmcplugin.addDirectoryItem(HANDLE,
                                build_url(mode="tmdb_detail", kind=kind, media_id=media_id),
                                item, True)


def tmdb_search(query="", page=1):
    token = require_tmdb()
    if not token:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    if not query:
        query = xbmcgui.Dialog().input("Cerca film o serie TV", type=xbmcgui.INPUT_ALPHANUM).strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, "Cerca: %s" % query)
    try:
        page = max(1, min(int(page), 500))
        films = tmdb.search(token, "movie", query, page)
        series = tmdb.search(token, "tv", query, page)
        for data in films.get("results") or []:
            tmdb_media_item(data, "movie", "Film · ")
        for data in series.get("results") or []:
            tmdb_media_item(data, "tv", "Serie TV · ")
        if page < max(films.get("total_pages", 0), series.get("total_pages", 0)):
            add_folder("Pagina successiva", mode="tmdb_search", query=query, page=page + 1)
        if not (films.get("results") or series.get("results")):
            notify("Nessun titolo trovato.")
        xbmcplugin.setContent(HANDLE, "videos")
    except Exception as exc:
        tmdb_error(exc)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tmdb_cinema(page=1):
    token = require_tmdb()
    if not token:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, "Al cinema in Italia · prossimi 60 giorni")
    try:
        page = max(1, min(int(page), 500))
        today = datetime.now(guide.ROME).date()
        result = tmdb.cinema(token, today, page=page)
        for data in result.get("results") or []:
            release = data.get("release_date") or ""
            tmdb_media_item(data, "movie", "%s · " % tmdb.italian_date(release))
        if page < result.get("total_pages", 0):
            add_folder("Pagina successiva", mode="tmdb_cinema", page=page + 1)
        if not result.get("results"):
            notify("Nessuna uscita italiana segnalata da TMDb per questa pagina.")
        xbmcplugin.setContent(HANDLE, "movies")
    except Exception as exc:
        tmdb_error(exc)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tmdb_series(page=1):
    token = require_tmdb()
    if not token:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, "Serie TV in arrivo · date TMDb non confermate per l'Italia")
    try:
        page = max(1, min(int(page), 500))
        today = datetime.now(guide.ROME).date()
        end = today + timedelta(days=60)
        result = tmdb.upcoming_series(token, today, page=page)
        shown = set()
        for data in result.get("results") or []:
            first_air = data.get("first_air_date") or ""
            if not today.isoformat() <= first_air <= end.isoformat():
                continue
            shown.add(data.get("id"))
            tmdb_media_item(data, "tv", "%s · Nuova serie · " % tmdb.italian_date(first_air))
        # L'API elenca nuove serie; per i titoli seguiti aggiungiamo anche il prossimo episodio noto.
        if page == 1:
            followed_series = [entry for entry in load_followed() if entry["kind"] == "Serie TV"]
            for entry in followed_series:
                try:
                    candidates = tmdb.search(token, "tv", entry["title"]).get("results") or []
                    match = next((data for data in candidates if is_followed(
                        {"kind": "Serie TV", "title": tmdb.title(data, "tv"), "year": ""}, entry)), None)
                    if not match or match.get("id") in shown:
                        continue
                    details = tmdb.detail(token, "tv", match["id"])
                    episode = details.get("next_episode_to_air") or {}
                    air_date = episode.get("air_date") or ""
                    if not today.isoformat() <= air_date <= end.isoformat():
                        continue
                    number = "S%s E%s" % (episode.get("season_number", "?"), episode.get("episode_number", "?"))
                    tmdb_media_item(details, "tv", "%s · %s · " % (tmdb.italian_date(air_date), number))
                except Exception as exc:
                    xbmc.log("[MediaHub Italia] Episodio seguito %s: %s" % (entry["title"], exc), xbmc.LOGWARNING)
        if page < result.get("total_pages", 0):
            add_folder("Pagina successiva", mode="tmdb_series", page=page + 1)
        if not result.get("results") and not shown:
            notify("Nessuna nuova serie segnalata da TMDb per questa pagina.")
        xbmcplugin.setContent(HANDLE, "tvshows")
    except Exception as exc:
        tmdb_error(exc)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tmdb_detail(kind, media_id):
    token = require_tmdb()
    try:
        if not token:
            return
        data = tmdb.detail(token, kind, media_id)
        italy = tmdb.providers(token, kind, media_id)
        name = tmdb.title(data, kind)
        lines = [name, "%s · %s" % ("Film" if kind == "movie" else "Serie TV", tmdb.year(data, kind) or "anno non indicato")]
        if kind == "movie":
            if data.get("runtime"):
                lines.append("Durata: %s minuti" % data["runtime"])
        else:
            if data.get("number_of_seasons"):
                lines.append("Stagioni: %s · Episodi: %s" % (data["number_of_seasons"], data.get("number_of_episodes", "?")))
            next_episode = data.get("next_episode_to_air") or {}
            if next_episode.get("air_date"):
                lines.append("Prossimo episodio TMDb: %s · S%s E%s (data italiana non confermata)" % (
                    tmdb.italian_date(next_episode["air_date"]),
                    next_episode.get("season_number", "?"), next_episode.get("episode_number", "?")))
        genres = ", ".join(g.get("name", "") for g in data.get("genres") or [] if g.get("name"))
        if genres:
            lines.append("Generi: " + genres)
        lines.extend(["", data.get("overview") or "Descrizione non disponibile.", "", "DOVE VEDERLO IN ITALIA"])
        groups = (("flatrate", "Abbonamento"), ("free", "Gratis"),
                  ("ads", "Gratis con pubblicità"), ("rent", "Noleggio"), ("buy", "Acquisto"))
        available = False
        for key, label in groups:
            names = tmdb.provider_names(italy, key)
            if names:
                lines.append("%s: %s" % (label, names))
                available = True
        if not available:
            lines.append("Nessuna piattaforma italiana segnalata da TMDb.")
        if italy.get("link"):
            lines.extend(["", "Scheda delle offerte: " + italy["link"]])
        lines.extend(["", "Disponibilità indicativa: controlla il servizio prima di abbonarti o acquistare.",
                      "Dati e immagini: TMDb · disponibilità: JustWatch via TMDb."])
        xbmcgui.Dialog().textviewer("Scheda titolo", "\n".join(lines))
    except Exception as exc:
        tmdb_error(exc)
    finally:
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tmdb_credits():
    xbmcplugin.setPluginCategory(HANDLE, "Crediti e fonti")
    item = xbmcgui.ListItem(label="TMDb · dati, immagini e uscite italiane")
    set_media_art(item, {"icon": os.path.join(os.path.dirname(__file__), "tmdb_logo.png"),
                         "thumb": os.path.join(os.path.dirname(__file__), "tmdb_logo.png")})
    item.setInfo("video", {"plot": "Questo prodotto usa l'API TMDb ma non è approvato né certificato da TMDb."})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="tmdb_credits_text"), item, True)
    add_folder("JustWatch · disponibilità e uscite streaming", mode="justwatch_info", icon="info",
               plot="Spiega la differenza tra offerte italiane mostrate nelle schede TMDb "
                    "e calendari streaming aperti sul sito JustWatch.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def tmdb_credits_text():
    xbmcgui.Dialog().textviewer("Crediti e fonti", (
        "MediaHub Italia\n\n"
        "Film, serie, locandine e uscite italiane: TMDb (The Movie Database).\n"
        "Questo prodotto usa l'API TMDb ma non è approvato né certificato da TMDb.\n"
        "This product uses the TMDB API but is not endorsed or certified by TMDB.\n"
        "https://www.themoviedb.org\n\n"
        "Disponibilità dei servizi in Italia: dati JustWatch distribuiti da TMDb. "
        "Le offerte possono cambiare; consulta il servizio prima di acquistare.\n\n"
        "In arrivo elenca le uscite cinematografiche italiane e le prime TV "
        "registrate su TMDb nei prossimi 60 giorni, oltre ai prossimi episodi "
        "delle serie seguite quando disponibili. Le date TV non garantiscono "
        "una prima visione in Italia. Le future uscite streaming italiane "
        "si consultano nelle pagine esterne di JustWatch; quei calendari non "
        "vengono importati nell'add-on."
    ))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def justwatch_info():
    xbmcgui.Dialog().textviewer("JustWatch · disponibilità e uscite", (
        "Nelle schede dei titoli, TMDb riporta le disponibilità italiane fornite "
        "da JustWatch, suddivise in abbonamento, gratuito, pubblicità, noleggio e acquisto.\n\n"
        "Le voci 'Serie TV in streaming' e 'Film in streaming' aprono invece "
        "direttamente il sito JustWatch Italia nel browser del dispositivo. "
        "L'add-on non legge o copia quei calendari: i titoli seguiti non possono "
        "essere contrassegnati con la stella nelle pagine esterne.\n\n"
        "Controlla sempre l'offerta sul servizio prima di abbonarti o acquistare.\n"
        "https://www.justwatch.com/it"
    ))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_guide(kind):
    xbmcplugin.setPluginCategory(HANDLE, "Film stasera" if kind == "Film" else "Serie TV stasera")
    try:
        items = evening_programmes()
        tracked = load_followed()
        shown = 0
        for index, programme in enumerate(items):
            if programme["kind"] != kind:
                continue
            hour = datetime.fromisoformat(programme["start"]).strftime("%H:%M")
            label = "%s · %s · %s" % (hour, programme["channel"], programme["title"])
            if kind == "Serie TV" and programme.get("episode"):
                season = "S%s " % programme["season"] if programme.get("season") else ""
                label += " [%sE%s]" % (season, programme["episode"])
            item = xbmcgui.ListItem(label=label)
            art = programme.get("image")
            set_media_art(item, {"icon": art, "thumb": art} if art else {"icon": "DefaultVideo.png"})
            item.setInfo("video", {"title": programme["title"], "plot": programme["description"]})
            add_follow_context(item, programme, tracked)
            xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="guide_detail", index=index), item, True)
            shown += 1
        if not shown:
            if not items:
                notify("La guida non contiene programmi per questa sera.")
            else:
                notify("Nessun %s classificato nella guida di stasera." % ("film" if kind == "Film" else "episodio di serie TV"))
        xbmcplugin.setContent(HANDLE, "videos")
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Guida TV: %s" % exc, xbmc.LOGERROR)
        notify("Guida TV non disponibile. Verifica la connessione o cambia fonte.")
        add_folder("[Modifica l'indirizzo della guida]", mode="guide_config")
        add_folder("[Ripristina la guida predefinita]", mode="guide_default")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def guide_detail(index, scope="evening"):
    try:
        programme = (schedule_programmes() if scope == "schedule" else evening_programmes())[int(index)]
        start = datetime.fromisoformat(programme["start"]).strftime("%d/%m/%Y %H:%M")
        stop = datetime.fromisoformat(programme["stop"]).strftime("%H:%M") if programme["stop"] else "?"
        lines = [programme["title"], "%s · %s–%s" % (programme["channel"], start, stop)]
        if programme.get("subtitle"):
            lines.append("%s: %s" % ("Titolo episodio" if programme["kind"] == "Serie TV" else "Sottotitolo", programme["subtitle"]))
        if programme.get("season") or programme.get("episode"):
            parts = []
            if programme.get("season"):
                parts.append("stagione %s" % programme["season"])
            if programme.get("episode"):
                parts.append("episodio %s" % programme["episode"])
            lines.append("Serie TV · %s" % ", ".join(parts))
        else:
            lines.append(programme["kind"] or "Programma TV")
        details = []
        if programme.get("year"):
            details.append("Anno: %s" % programme["year"])
        if programme.get("country"):
            details.append("Paese: %s" % programme["country"])
        if programme.get("genres"):
            details.append("Genere: %s" % ", ".join(programme["genres"]))
        if programme.get("director"):
            details.append("Regia: %s" % programme["director"])
        if programme.get("cast"):
            details.append("Interpreti: %s" % programme["cast"])
        lines.extend(["", *details, "", programme["description"] or "Descrizione non presente nella guida.", "", "Per seguire questo titolo: tieni premuto OK nell'elenco.", "Fonte: guida XMLTV configurata"])
        xbmcgui.Dialog().textviewer("Scheda programma", "\n".join(lines))
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Scheda guida: %s" % exc, xbmc.LOGERROR)
        notify("Scheda non disponibile: aggiorna la guida TV.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def get_m3u_source(source_id):
    if source_id in M3U_PRESETS:
        return dict(M3U_PRESETS[source_id])
    for source in load_custom_sources():
        if source.get("id") == source_id:
            return source
    return None


def _media_type_dialog(default="auto"):
    choices = (("auto", "Automatico"), ("tv", "TV in diretta"), ("radio", "Radio"), ("vod", "Video / VOD"))
    preselect = next((index for index, item in enumerate(choices) if item[0] == default), 0)
    selected = xbmcgui.Dialog().select("Tipo di contenuto", [item[1] for item in choices], preselect=preselect)
    return choices[selected][0] if selected >= 0 else None


def add_m3u_source(kind):
    dialog = xbmcgui.Dialog()
    if kind == "url":
        location = dialog.input("Indirizzo della lista M3U", defaultt="https://", type=xbmcgui.INPUT_ALPHANUM).strip()
        parsed = urllib.parse.urlparse(location)
        if not location or parsed.scheme not in ("http", "https"):
            if location:
                notify("Inserisci un indirizzo http:// o https:// valido.")
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return
    else:
        location = dialog.browseSingle(1, "Scegli una lista M3U", "files", ".m3u|.m3u8").strip()
        if not location:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return

    suggested = location.rstrip("/\\").rsplit("/", 1)[-1] or "La mia lista"
    name = dialog.input("Nome della lista", defaultt=suggested, type=xbmcgui.INPUT_ALPHANUM).strip()
    if not name:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    media_type = _media_type_dialog()
    if media_type is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return

    sources = load_custom_sources()
    sources.append({
        "id": uuid.uuid4().hex,
        "name": name,
        "location": location,
        "kind": kind,
        "media_type": media_type,
    })
    save_custom_sources(sources)
    notify("Lista M3U aggiunta: %s" % name)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def edit_m3u_source(source_id):
    source = get_m3u_source(source_id)
    if not source or source.get("preset"):
        notify("Questa sorgente non può essere modificata.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    dialog = xbmcgui.Dialog()
    name = dialog.input("Nome della lista", defaultt=source.get("name", ""), type=xbmcgui.INPUT_ALPHANUM).strip()
    if not name:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    location = source.get("location", "")
    if source.get("kind") == "url":
        location = dialog.input("Indirizzo della lista M3U", defaultt=location, type=xbmcgui.INPUT_ALPHANUM).strip()
        if urllib.parse.urlparse(location).scheme not in ("http", "https"):
            notify("Indirizzo non valido.")
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
            return
    else:
        replacement = dialog.browseSingle(1, "Scegli la lista M3U", "files", ".m3u|.m3u8", False, False, location)
        if replacement:
            location = replacement
    media_type = _media_type_dialog(source.get("media_type", "auto"))
    if media_type is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    sources = load_custom_sources()
    for item in sources:
        if item.get("id") == source_id:
            item.update({"name": name, "location": location, "media_type": media_type})
            break
    save_custom_sources(sources)
    notify("Lista M3U aggiornata.")
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def delete_m3u_source(source_id):
    source = get_m3u_source(source_id)
    if not source or source.get("preset"):
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    if xbmcgui.Dialog().yesno(ADDON_NAME, "Eliminare la lista '%s'?" % source.get("name", "")):
        save_custom_sources([item for item in load_custom_sources() if item.get("id") != source_id])
        notify("Lista M3U eliminata.")
        xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def read_m3u_source(source):
    location = source.get("location", "")
    if source.get("kind") == "url":
        request = urllib.request.Request(location, headers={"User-Agent": HEADERS["User-Agent"], "Accept": "audio/x-mpegurl, application/vnd.apple.mpegurl, text/plain, */*"})
        raw = None
        for attempt in range(2):
            try:
                with urllib.request.urlopen(request, timeout=20) as response:
                    raw = response.read(MAX_PLAYLIST_BYTES + 1)
                break
            except urllib.error.HTTPError as exc:
                if attempt == 0 and 500 <= exc.code < 600:
                    xbmc.log("[MediaHub Italia] Errore HTTP %s, nuovo tentativo M3U" % exc.code, xbmc.LOGWARNING)
                    continue
                raise
        if len(raw) > MAX_PLAYLIST_BYTES:
            raise RuntimeError("La lista supera il limite di 5 MB")
        return raw.decode("utf-8-sig", errors="replace")
    handle = xbmcvfs.File(location)
    raw = handle.read(MAX_PLAYLIST_BYTES + 1)
    handle.close()
    if len(raw) > MAX_PLAYLIST_BYTES:
        raise RuntimeError("La lista supera il limite di 5 MB")
    if isinstance(raw, bytes):
        return raw.decode("utf-8-sig", errors="replace")
    return raw.lstrip("\ufeff")


def parse_m3u(text, base_location=""):
    entries = []
    pending = None
    attrs_pattern = re.compile(r'([\w-]+)\s*=\s*"([^"]*)"')
    for original in text.splitlines():
        line = original.strip()
        if not line:
            continue
        if line.upper().startswith("#EXTINF:"):
            payload = line.split(":", 1)[1]
            metadata, separator, title = payload.partition(",")
            attrs = {key.lower(): value for key, value in attrs_pattern.findall(metadata)}
            pending = {
                "title": title.strip() if separator else "",
                "group": attrs.get("group-title", "").strip(),
                "logo": attrs.get("tvg-logo", "").strip(),
                "channel": attrs.get("tvg-chno", "").strip(),
                "headers": {},
            }
            continue
        if pending is not None and line.upper().startswith("#EXTGRP:"):
            pending["group"] = line.split(":", 1)[1].strip()
            continue
        if pending is not None and line.upper().startswith("#EXTVLCOPT:"):
            option = line.split(":", 1)[1]
            key, separator, value = option.partition("=")
            if separator and key.lower() in ("http-user-agent", "http-referrer", "http-referer"):
                header = "User-Agent" if key.lower() == "http-user-agent" else "Referer"
                pending["headers"][header] = value.strip()
            continue
        if line.startswith("#"):
            continue
        if pending is None:
            pending = {"title": "", "group": "", "logo": "", "channel": "", "headers": {}}
        if base_location.startswith(("http://", "https://")):
            stream_url = urllib.parse.urljoin(base_location, line)
        else:
            stream_url = line
        parsed = urllib.parse.urlparse(stream_url.split("|", 1)[0])
        if parsed.scheme not in ("http", "https", "smb", "nfs", "special", "file") and not stream_url.startswith("/"):
            pending = None
            continue
        pending["url"] = stream_url
        pending["title"] = pending["title"] or stream_url.rsplit("/", 1)[-1] or "Senza titolo"
        entries.append(pending)
        pending = None
        if len(entries) >= MAX_PLAYLIST_ITEMS:
            break
    return entries


def m3u_root():
    xbmcplugin.setPluginCategory(HANDLE, "Le mie liste M3U")
    for source in load_custom_sources():
        add_folder(source.get("name", "Lista senza nome"), mode="m3u_source", source_id=source.get("id", ""),
                   icon="list", plot="Carica i contenuti della tua lista M3U salvata.")
    add_folder("Aggiungi lista da Internet", mode="m3u_add", kind="url", icon="list",
               plot="Salva l'indirizzo diretto di una lista M3U o M3U8 accessibile online.")
    add_folder("Aggiungi lista da file", mode="m3u_add", kind="file", icon="list",
               plot="Scegli un file M3U o M3U8 disponibile sul dispositivo o in una sorgente Kodi.")
    add_folder("Gestisci le mie liste", mode="m3u_manage", icon="settings",
               plot="Modifica il nome, l'indirizzo o il tipo delle liste personali oppure eliminale.")
    add_folder("Come funzionano le liste M3U", mode="m3u_info", icon="info",
               plot="Spiega formati supportati, riproduzione e limiti delle sorgenti personali.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def m3u_tundrak_root():
    # Un vecchio preferito Kodi puo' ancora richiamare questa route.
    list_m3u("tundrak_plus")


def m3u_manage():
    xbmcplugin.setPluginCategory(HANDLE, "Gestisci liste M3U")
    sources = load_custom_sources()
    if not sources:
        notify("Non hai ancora aggiunto liste personali.")
    for source in sources:
        source_id = source.get("id", "")
        add_folder("Modifica: %s" % source.get("name", "Lista"), mode="m3u_edit", source_id=source_id)
        add_folder("Elimina: %s" % source.get("name", "Lista"), mode="m3u_delete", source_id=source_id)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def list_m3u(source_id, group=None):
    source = get_m3u_source(source_id)
    if not source:
        notify("Sorgente M3U non trovata.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, source.get("name", "Lista M3U"))
    try:
        entries = parse_m3u(read_m3u_source(source), source.get("location", ""))
        groups = sorted({entry.get("group", "") for entry in entries if entry.get("group")}, key=str.casefold)
        if group is None and groups:
            add_folder("Tutti", mode="m3u_source", source_id=source_id, group="__all__")
            for name in groups:
                add_folder(name, mode="m3u_source", source_id=source_id, group=name)
        else:
            selected = entries if group in (None, "__all__") else [entry for entry in entries if entry.get("group") == group]
            for entry in selected:
                title = entry.get("title", "Senza titolo")
                if entry.get("channel"):
                    title = "%s · %s" % (entry["channel"], title)
                item = xbmcgui.ListItem(label=title)
                item.setProperty("IsPlayable", "true")
                media_type = source.get("media_type", "auto")
                info_kind = "music" if media_type == "radio" else "video"
                try:
                    item.setInfo(info_kind, {"title": entry.get("title", title), "genre": entry.get("group", "")})
                except Exception:
                    pass
                if entry.get("logo"):
                    set_media_art(item, {"icon": entry["logo"], "thumb": entry["logo"]})
                xbmcplugin.addDirectoryItem(HANDLE, build_url(mode="m3u_play", stream_url=entry["url"], headers=json.dumps(entry.get("headers", {})), media_type=media_type), item, False)
            xbmcplugin.setContent(HANDLE, "songs" if source.get("media_type") == "radio" else "videos")
        if not entries:
            notify("La lista non contiene elementi riproducibili.")
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Errore lista M3U: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile aprire la lista M3U. Consulta il log di Kodi.")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def play_m3u(stream_url, headers_json="{}", media_type="auto"):
    try:
        headers = json.loads(headers_json or "{}")
        if not isinstance(headers, dict):
            headers = {}
        header_query = urllib.parse.urlencode(headers)
        playback_url = stream_url + (("&" if "|" in stream_url else "|") + header_query if header_query else "")
        item = xbmcgui.ListItem(path=playback_url)
        item.setProperty("IsPlayable", "true")
        clean_path = urllib.parse.urlparse(stream_url.split("|", 1)[0]).path.lower()
        if clean_path.endswith(".m3u8"):
            item.setMimeType("application/vnd.apple.mpegurl")
            item.setContentLookup(False)
        elif clean_path.endswith(".mpd"):
            item.setProperty("inputstream", "inputstream.adaptive")
            item.setProperty("inputstream.adaptive.manifest_type", "mpd")
            if header_query:
                item.setProperty("inputstream.adaptive.manifest_headers", header_query)
                item.setProperty("inputstream.adaptive.stream_headers", header_query)
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    except Exception as exc:
        xbmc.log("[MediaHub Italia] Playback M3U fallito: %s" % exc, xbmc.LOGERROR)
        notify("Riproduzione non disponibile.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def show_m3u_info():
    text = (
        "Liste M3U\n\nPuoi aprire le raccolte IPTV Italia oppure aggiungere liste "
        "personali tramite indirizzo Internet o file .m3u/.m3u8. Sono supportati "
        "canali TV, radio e VOD riproducibili direttamente da Kodi.\n\n"
        "Le raccolte predefinite sono lette dai progetti peppenamir/iptv_italia "
        "e Tundrak/IPTV-Italia: MediaHub Italia non ne copia né gestisce i contenuti.\n\n"
        "Non sono supportati portali Xtream, credenziali o aggiramenti DRM. "
        "Usa soltanto liste e flussi che sei autorizzato a riprodurre."
    )
    xbmcgui.Dialog().textviewer("Liste M3U", text)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def add_playable(label, channel_id, plot="", art=None):
    item = xbmcgui.ListItem(label=label)
    item.setProperty("IsPlayable", "true")
    try:
        item.setInfo("video", {"title": label, "plot": plot})
    except Exception:
        pass
    if art:
        set_media_art(item, art)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url(mode="play", channel_id=channel_id),
        item,
        False,
    )


def channel_image(channel):
    # L'API ha cambiato nel tempo i nomi dei campi immagini: proviamo i più comuni.
    candidates = []
    for key in ("images", "image", "artwork", "artworks"):
        value = channel.get(key)
        if isinstance(value, dict):
            candidates.extend(value.values())
        elif isinstance(value, list):
            candidates.extend(value)
        elif isinstance(value, str):
            candidates.append(value)
    for value in candidates:
        if isinstance(value, dict):
            for k in ("url", "src", "original", "medium", "large"):
                if isinstance(value.get(k), str) and value[k].startswith("http"):
                    return value[k]
        elif isinstance(value, str) and value.startswith("http"):
            return value
    return ""


def categories_map():
    mapping = {}
    categories = get_categories()
    for category in categories:
        name = category.get("name") or category.get("title") or "Altro"
        ids = category.get("live_channels", []) or []
        for channel_id in ids:
            if isinstance(channel_id, dict):
                channel_id = channel_id.get("id")
            if channel_id:
                mapping[str(channel_id)] = name
    return categories, mapping


def root():
    xbmcplugin.setPluginCategory(HANDLE, ADDON_NAME)
    add_folder("Cerca film e serie", mode="tmdb_search", icon="search",
               plot="Apre la ricerca TMDb. Seleziona un titolo per leggere la scheda "
                    "e le piattaforme che lo offrono in Italia.")
    add_folder("In arrivo", mode="upcoming", icon="calendar",
               plot="Film al cinema in Italia e serie da TMDb nei prossimi 60 giorni; "
                    "film e serie in streaming sui calendari italiani di JustWatch nel browser.")
    add_folder("Stasera in TV", mode="evening", icon="moon",
               plot="Mostra separatamente i film e le serie della serata dalla guida TV XMLTV configurata.")
    add_folder("Titoli seguiti", mode="followed_root", icon="star",
               plot="Consulta i film e le serie che segui e i loro prossimi passaggi segnalati dalla guida TV.")
    add_folder("Canali e liste", mode="watch", icon="play",
               plot="Accedi a Rakuten TV Live, YouTube, liste pubbliche TV e radio e liste M3U personali.")
    add_folder("Pulizia e spazio", mode="clean_cache", icon="settings",
               plot="Pulisce la cache della guida TV, le immagini registrate da MediaHub Italia "
                    "e i suoi file temporanei. Chiede conferma e conserva preferenze, liste e titoli seguiti.")
    add_folder("Impostazioni e fonti", mode="settings", icon="settings",
               plot="Gestisci il codice TMDb e la guida TV; leggi spiegazioni, crediti e limiti delle fonti.")
    xbmcplugin.endOfDirectory(HANDLE)


def youtube_root():
    xbmcplugin.setPluginCategory(HANDLE, "YouTube")
    for label, channel_id in YOUTUBE_CHANNELS:
        # La pagina canale richiede YouTube Data API per ricavare la playlist
        # degli upload. Il relativo ID e' invece deterministico: prefisso UU
        # seguito dal Channel ID senza UC. Aprendo direttamente tale playlist,
        # plugin.video.youtube 7.4.4 usa il proprio fallback pubblico e non
        # richiede una API key personale per mostrare i video.
        uploads_playlist_id = "UU" + channel_id[2:]
        add_external_folder(
            label,
            "plugin://plugin.video.youtube/playlist/%s/" % uploads_playlist_id,
            icon="youtube",
            plot="Apre gli ultimi video pubblicati da %s tramite l'add-on YouTube per Kodi." % label,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def rakuten_root():
    xbmcplugin.setPluginCategory(HANDLE, "Rakuten TV")
    add_folder("Tutti i canali Live gratuiti", mode="channels", icon="play",
               plot="Elenca tutti i canali Live gratuiti disponibili per il mercato italiano.")
    try:
        categories = get_categories()
        for category in categories:
            name = category.get("name") or category.get("title")
            if name:
                add_folder(name, mode="channels", category=name, icon="tv",
                           plot="Filtra i canali Live gratuiti nella categoria %s." % name)
    except Exception:
        # Se l'endpoint categorie non risponde, l'elenco completo resta comunque disponibile.
        pass
    add_folder("Informazioni su Rakuten TV", mode="info", icon="info",
               plot="Spiega quali canali sono disponibili e i limiti della riproduzione.")
    xbmcplugin.endOfDirectory(HANDLE)


def list_channels(category=None):
    xbmcplugin.setPluginCategory(HANDLE, "Rakuten TV - Live")
    try:
        channels = get_channels()
        mapping = {}
        if category:
            try:
                _, mapping = categories_map()
            except Exception:
                mapping = {}

        shown = 0
        for channel in channels:
            channel_id = str(channel.get("id", ""))
            if not channel_id:
                continue
            if category and mapping.get(channel_id) != category:
                continue

            title = channel.get("title") or channel.get("name") or channel_id
            description = channel.get("description") or channel.get("short_description") or ""
            image = channel_image(channel)
            art = {"thumb": image, "poster": image, "icon": image} if image else None
            add_playable(title, channel_id, description, art)
            shown += 1

        if shown == 0:
            notify("Nessun canale restituito per questa sezione.")
        xbmcplugin.setContent(HANDLE, "videos")
    except ApiHttpError as exc:
        notify("Rakuten TV: errore HTTP %s nel recupero dei canali." % exc.code)
    except Exception as exc:
        xbmc.log("[MediaHub Italia] channel list error: %s" % exc, xbmc.LOGERROR)
        notify("Impossibile recuperare i canali Rakuten TV. Consulta il log di Kodi.")
    xbmcplugin.endOfDirectory(HANDLE)


def find_channel(channel_id):
    for channel in get_channels():
        if str(channel.get("id", "")) == str(channel_id):
            return channel
    return None


def first_language_id(channel):
    labels = channel.get("labels", {}) if isinstance(channel, dict) else {}
    languages = labels.get("languages", []) if isinstance(labels, dict) else []
    for language in languages:
        if isinstance(language, dict) and language.get("id"):
            return language["id"]
    return "MIS"


def play_channel(channel_id):
    try:
        channel = find_channel(channel_id)
        if not channel:
            raise RuntimeError("Canale non trovato")

        params = rakuten_params()
        params.update({
            "device_stream_audio_quality": "2.0",
            "device_stream_hdr_type": "NONE",
            "device_stream_video_quality": "FHD",
            "disable_dash_legacy_packages": "false",
        })
        payload = {
            "audio_language": first_language_id(channel),
            "audio_quality": "2.0",
            "classification_id": CLASSIFICATION_ID,
            "content_id": channel_id,
            "content_type": "live_channels",
            "device_serial": "kodi-personal-addon",
            "player": "web:HLS-NONE:NONE",
            "strict_video_quality": False,
            "subtitle_language": "MIS",
            "video_type": "stream",
        }

        result = api_request("/avod/streamings", method="POST", params=params, payload=payload)
        infos = (result.get("data", {}) or {}).get("stream_infos", []) or []
        if not infos:
            raise RuntimeError("Rakuten non ha restituito uno stream")

        stream_url = infos[0].get("url")
        if not stream_url:
            raise RuntimeError("URL stream assente")

        # Manteniamo l'URL restituito dal servizio senza manipolare DRM o token.
        item = xbmcgui.ListItem(path=stream_url)
        item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
    except Exception as exc:
        xbmc.log("[MediaHub Italia] playback error: %s" % exc, xbmc.LOGERROR)
        notify("Riproduzione non disponibile per questo canale.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def show_info():
    text = (
        "Rakuten TV - integrazione personale\n\n"
        "Questa versione usa gli endpoint del servizio per elencare e riprodurre "
        "i canali Live gratuiti disponibili per il mercato italiano.\n\n"
        "Non gestisce acquisti, noleggi, account o contenuti VOD protetti da DRM. "
        "Non rimuove né aggira protezioni.\n\n"
        "Sito ufficiale: https://www.rakuten.tv/it\n\n"
        "Se Rakuten modifica le proprie API, alcune funzioni potrebbero richiedere un aggiornamento dell'addon."
    )
    xbmcgui.Dialog().textviewer("Rakuten TV", text)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def router():
    query = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 and sys.argv[2] else {}
    mode = query.get("mode", [""])[0]

    if not mode:
        root()
    elif mode == "discover":
        discover_root()
    elif mode == "upcoming":
        upcoming_root()
    elif mode == "public_site":
        open_public_site(query.get("source", [""])[0])
    elif mode == "evening":
        evening_root()
    elif mode == "followed_root":
        followed_root()
    elif mode == "followed_airings":
        followed_airings()
    elif mode == "watch":
        watch_root()
    elif mode == "tv_radio":
        tv_radio_root()
    elif mode == "settings":
        settings_root()
    elif mode == "guide_settings":
        guide_settings_root()
    elif mode == "guide_source_info":
        guide_source_info()
    elif mode == "about":
        mediahub_about()
    elif mode == "menu_info":
        show_menu_info(query.get("title", ["Informazioni"])[0],
                       query.get("description", [""])[0])
    elif mode == "tmdb_config":
        configure_tmdb()
    elif mode == "tmdb_verify":
        verify_tmdb()
    elif mode == "tmdb_help":
        tmdb_help()
    elif mode == "tmdb_search":
        tmdb_search(query.get("query", [""])[0], query.get("page", ["1"])[0])
    elif mode == "tmdb_cinema":
        tmdb_cinema(query.get("page", ["1"])[0])
    elif mode == "tmdb_series":
        tmdb_series(query.get("page", ["1"])[0])
    elif mode == "tmdb_detail":
        tmdb_detail(query.get("kind", [""])[0], query.get("media_id", [""])[0])
    elif mode == "tmdb_credits":
        tmdb_credits()
    elif mode == "tmdb_credits_text":
        tmdb_credits_text()
    elif mode == "justwatch_info":
        justwatch_info()
    elif mode == "guide_films":
        list_guide("Film")
    elif mode == "guide_series":
        list_guide("Serie TV")
    elif mode == "followed":
        list_followed()
    elif mode == "followed_title":
        followed_title(query.get("key", [""])[0])
    elif mode == "follow_toggle":
        toggle_follow(query.get("kind", [""])[0], query.get("title", [""])[0], query.get("year", [""])[0])
    elif mode == "guide_config":
        configure_guide()
    elif mode == "guide_default":
        restore_default_guide()
    elif mode == "guide_detail":
        guide_detail(query.get("index", ["-1"])[0], query.get("scope", ["evening"])[0])
    elif mode == "rakuten":
        rakuten_root()
    elif mode == "youtube":
        youtube_root()
    elif mode == "m3u":
        m3u_root()
    elif mode == "m3u_tundrak":
        m3u_tundrak_root()
    elif mode == "clean_cache":
        clean_cache()
    elif mode == "m3u_source":
        list_m3u(query.get("source_id", [""])[0], query.get("group", [None])[0])
    elif mode == "m3u_add":
        add_m3u_source(query.get("kind", ["url"])[0])
    elif mode == "m3u_manage":
        m3u_manage()
    elif mode == "m3u_edit":
        edit_m3u_source(query.get("source_id", [""])[0])
    elif mode == "m3u_delete":
        delete_m3u_source(query.get("source_id", [""])[0])
    elif mode == "m3u_play":
        play_m3u(
            query.get("stream_url", [""])[0],
            query.get("headers", ["{}"])[0],
            query.get("media_type", ["auto"])[0],
        )
    elif mode == "m3u_info":
        show_m3u_info()
    elif mode == "channels":
        list_channels(query.get("category", [None])[0])
    elif mode == "play":
        play_channel(query.get("channel_id", [""])[0])
    elif mode == "info":
        show_info()
    else:
        root()


if __name__ == "__main__":
    try:
        router()
    finally:
        save_artwork_seen()
