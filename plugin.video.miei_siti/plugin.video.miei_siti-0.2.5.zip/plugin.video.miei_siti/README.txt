MEDIAHUB ITALIA - versione 0.2.5 (Kodi 21.2 Omega)

CHE COS'E'
MediaHub Italia aiuta a scegliere cosa guardare e riunisce alcune fonti
video in Kodi: schede di film e serie, offerte disponibili in Italia,
uscite cinematografiche, guida TV, titoli seguiti e canali gratuiti.
Le date e le offerte dipendono dalle fonti e possono cambiare.

INSTALLAZIONE
Kodi > Add-on > Installa da un file ZIP > plugin.video.miei_siti-0.2.5.zip.
Se richiesto, abilita prima Impostazioni > Sistema > Add-on > Sorgenti sconosciute.
Gli aggiornamenti conservano codice TMDb, guida TV e liste personali nel
profilo locale dell'add-on: non sono inclusi nello ZIP.

MENU PRINCIPALE
- Cerca film e serie: ricerca TMDb; la scheda del titolo mostra trama,
  anno e offerte italiane di abbonamento, gratis, noleggio e acquisto.
- In arrivo: quattro voci dirette. Film in arrivo - TMDb mostra i film al
  cinema in Italia nei prossimi 60 giorni. Serie TV in arrivo - TMDb mostra
  nuove serie datate entro 60 giorni e i prossimi episodi delle serie seguite
  quando TMDb li segnala. Le date TV non confermano l'uscita italiana.
  Film e Serie in arrivo dal sito JustWatch aprono le pagine streaming Italia.
  Su Android queste pagine si aprono nel browser; altrove viene mostrato
  l'indirizzo. I titoli seguiti non sono evidenziati sul sito esterno.
- Stasera in TV: elenchi Film e Serie TV ricavati dalla guida XMLTV;
  stagione ed episodio compaiono quando la fonte li fornisce.
- Titoli seguiti: elenco personale e futuri passaggi nella guida TV.
  Per seguire un titolo tieni premuto OK sulla scheda e scegli il comando.
- Canali e liste: Rakuten Live gratuito, canali YouTube selezionati,
  liste TV/Radio Italia preimpostate e liste M3U personali. La voce Tundrak
  apre direttamente la lista Completa; Peppenamir e' una fonte diversa.
- Pulizia e spazio: dal primo menu, con una sola conferma, pulisce la guida,
  le immagini registrate dall'add-on e gli eventuali file temporanei propri.
  Non cancella codice TMDb, liste personali, guida configurata o titoli seguiti.
  Le immagini viste prima della 0.2.5 non sono nel registro delle immagini.
- Impostazioni e fonti: codice TMDb, guida TV, spiegazioni e crediti.

Le voci dei menu hanno descrizioni e piccole icone. Dal menu contestuale
('tieni premuto OK') scegli 'Cosa fa questa voce?' per leggere la
spiegazione; la schermata 'Che cos'e MediaHub Italia' illustra l'insieme.

CODICE TMDB
In Impostazioni e fonti > Inserisci/Cambia il codice TMDb, incolla la
'API Key' breve oppure 'API Read Access Token' lungo. Il codice viene
verificato con una richiesta a TMDb prima del salvataggio. Non inserire
email o password e non condividere il codice in chat. La chiave breve e'
inviata a TMDb nell'URL di una richiesta HTTPS, quella lunga nell'header.

GUIDA TV
La fonte italiana predefinita e':
https://epgshare01.online/epgshare01/epg_ripper_IT1.xml.gz
Fonte alternativa: https://www.open-epg.com/files/italy3.xml.gz
Puoi impostare una guida personale XML o XML.GZ da Impostazioni e fonti.
La guida puo' elencare canali non presenti nelle liste M3U: la sua scheda
e' informativa. Le categorie Film e Serie TV dipendono dai dati XMLTV.

FONTI E LIMITI
TMDb fornisce schede, immagini, date dei film al cinema e date TV. Le
date delle serie e degli episodi possono riferirsi alla prima estera. Le disponibilita'
italiane nelle schede provengono da JustWatch tramite TMDb. Le pagine
JustWatch sulle future uscite in streaming vengono aperte nel browser:
non sono copiate nell'add-on e non applicano il filtro locale di 60 giorni.
Questo prodotto usa l'API TMDb ma non e' approvato ne' certificato da TMDb.
This product uses the TMDB API but is not endorsed or certified by TMDB.
https://www.themoviedb.org - https://www.justwatch.com/it

I canali gratuiti e le liste M3U dipendono dai rispettivi fornitori.
La sezione YouTube usa plugin.video.youtube. I cataloghi protetti da DRM
di Netflix, Prime Video e altri servizi non si riproducono nell'add-on.
